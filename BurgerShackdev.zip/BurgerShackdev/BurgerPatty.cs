﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class BurgerPatty
    {
        private Texture2D burgerTexture;
        private Vector2 burgerPosition;
        private Rectangle burgerPattyCollisionBox;
        private int burgerPattyWidth;
        private int burgerPattyHeight;
        private float fBurgerZoom;
        private float fmovementSpeed;
        private BurgerPattyState bpState;
        private bool bFlaggedDelete;
        public  enum BurgerPattyState{OnBelt,Falling,OnBun };

        public int BurgerPattyWidth
        {
            get { return burgerPattyWidth; }
            set { burgerPattyWidth = value; }
        }
        public int BurgerPattyHeight
        {
            get { return burgerPattyHeight; }
            set { burgerPattyHeight = value; }
        }
        public Rectangle BurgerPattyCollisionBox
        {
            get { return burgerPattyCollisionBox; }
            set { burgerPattyCollisionBox = value; }
        }

        public BurgerPattyState BPState
        {
            get { return bpState; }
            set { bpState = value; }
        }
        public float FMovementSpeed
        {
            get { return fmovementSpeed; }
            set { fmovementSpeed = value; }
        }
        public bool BFlaggedDelete
        {
            get { return bFlaggedDelete; }
            set { bFlaggedDelete = value; }
        }

        //Constructors
        public BurgerPatty()
        {
            //Set the initial state of the  patty
            bpState = BurgerPattyState.OnBun;
        }

        public BurgerPatty(Vector2 startPosition)
        {
            burgerPosition = new Vector2(startPosition.X, startPosition.Y);
            //burgerPattyCollisionBox = new Rectangle((int)burgerPosition.X-(int)burgerPattyWidth/2, (int)burgerPosition.Y-(int)burgerPattyHeight/2, burgerPattyWidth, burgerPattyHeight);
            //burgerPattyCollisionBox = new Rectangle((int)(burgerPosition.X * fBurgerZoom), (int)(burgerPosition.Y - burgerPattyHeight / 2 * fBurgerZoom), burgerPattyWidth, burgerPattyHeight);
            burgerPattyCollisionBox = new Rectangle((int)(burgerPosition.X), (int)(burgerPosition.Y), burgerPattyWidth, (int)(burgerPattyHeight));

            fBurgerZoom = 0.5f;
            fmovementSpeed = 1f;
            //Set the initial state of the burger patty
            bpState = BurgerPattyState.Falling;
        }
        public void LoadContent(ContentManager Content)
        {

            burgerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/burgerPatty");
            burgerPattyWidth = (int)(burgerTexture.Width*fBurgerZoom);
            burgerPattyHeight = (int)(burgerTexture.Height * fBurgerZoom); ;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            spriteBatch.Draw(burgerTexture, burgerPosition, null, Color.White, 0f,
            Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
        }
        public void Update(GameTime gameTime,List<Belt> listBelts)
        {

            //In this update we move the burger patty to the left until it is no longer in contact with the conveyer belt up top, falls to the bottom on bun,then it falls to the burger assembly
            switch (bpState)
            {
                case BurgerPattyState.Falling:

                burgerPosition = new Vector2(burgerPosition.X, burgerPosition.Y+1);
                    break;
                case BurgerPattyState.OnBelt:
                    burgerPosition = new Vector2(burgerPosition.X - 1*fmovementSpeed, burgerPosition.Y);
                    break;
                //Placed on Converyor
                case BurgerPattyState.OnBun:
                    burgerPosition = new Vector2(burgerPosition.X, burgerPosition.Y + 1);
                    break;

            }
            
            //Check for collsion of the patty with the belts
            foreach (Belt belt in listBelts)
            {
                if (burgerPattyCollisionBox.Intersects(belt.BeltCollisionBox))
                
                
                {
                    //Move left if on belt.
                    bpState = BurgerPattyState.OnBelt;
                    //Let's just break out of the loop!
                    break;

                }
                else
                {
                    
                    bpState = BurgerPattyState.Falling;
                   
                }
               
            }

            burgerPattyCollisionBox = new Rectangle((int)(burgerPosition.X), (int)(burgerPosition.Y), burgerPattyWidth, (int)(burgerPattyHeight));
        }
    }
}
