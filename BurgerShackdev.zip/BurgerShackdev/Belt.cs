﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class Belt
    {
        public enum beltType { top, bottom };
        private beltType beltPositionType;
        private Texture2D beltTexture;
        private Vector2 beltPosition;
        private Rectangle beltCollisionBox;
        private float fBeltZoom;
        public beltType BeltPositionType
        {
            get { return beltPositionType; }
            set { beltPositionType = value; }
        }
        public Texture2D BeltTexture
        {
            get { return beltTexture; }
            set { beltTexture = value; }
        }
        public Vector2 BeltPosition
        {
            get { return beltPosition; }
            set { beltPosition = value; }
        }
        public Rectangle BeltCollisionBox
        {
            get { return beltCollisionBox; }
            set { beltCollisionBox = value; }
        }
        //Constructor
        public Belt(beltType beltType,Vector2 beltPosition,ContentManager Content)
        {
            this.beltPositionType = beltType;
            this.beltPosition = beltPosition;
            switch (beltType)
            {
                case beltType.top:
                    this.beltTexture = Content.Load<Texture2D>("Belts/topBelt");
                    break;
                case beltType.bottom:
                    this.beltTexture = Content.Load<Texture2D>("Belts/bottomBelt");
                    break;
            }
            this.beltCollisionBox = new Rectangle((int)beltPosition.X , (int)beltPosition.Y + beltTexture.Height / 2-6, beltTexture.Width, beltTexture.Height);
            fBeltZoom = 1.0f;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(beltTexture, beltPosition, null, Color.White, 0f,
            Vector2.Zero, fBeltZoom, SpriteEffects.None, 0f);


        }
        public void Update(GameTime gameTime)
        {
            //Update code here.
            
        }
    }
}
