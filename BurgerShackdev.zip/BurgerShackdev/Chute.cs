﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class Chute
    {
        private string chuteName;
        private Texture2D chuteTexture;
        private Vector2 chutePosition;
        private Rectangle chuteRectangle;

        public Rectangle ChuteRectangle
        {
            get { return chuteRectangle; }
            set { chuteRectangle = value; }
        }
        public Vector2 ChutePosition
        {
            get { return chutePosition; }
            set { chutePosition = value; }
        }
        public string ChuteName
        {
            get { return chuteName; }
            set { chuteName = value; }
        }
        public Chute(string chuteName)
        {
            this.chuteName = chuteName;
            
        }
        public void LoadContent(ContentManager Content,int screenWidth)
        {
            switch (chuteName)
            {
                case "onion":
                    chuteTexture = Content.Load<Texture2D>("burgerComponents/ComponentChute/OnionChute");
                    chutePosition = new Vector2(screenWidth - chuteTexture.Width, 175);
                    break;
                case "cheese":
                    chuteTexture = Content.Load<Texture2D>("burgerComponents/ComponentChute/CheeseChute");
                    chutePosition = new Vector2(screenWidth - chuteTexture.Width, 220);
                    break;
                case "lettuce":
                    chuteTexture = Content.Load<Texture2D>("burgerComponents/ComponentChute/LettuceChute");
                    chutePosition = new Vector2(screenWidth - chuteTexture.Width, 270);
                    break;
                case "tomato":
                    chuteTexture = Content.Load<Texture2D>("burgerComponents/ComponentChute/TomatoChute");
                    chutePosition = new Vector2(screenWidth - chuteTexture.Width, 320);
                    break;
                case "topbun":
                    chuteTexture = Content.Load<Texture2D>("burgerComponents/ComponentChute/TopBunChute");
                    chutePosition = new Vector2(screenWidth - chuteTexture.Width, 375);
                    break;

            }

            chuteRectangle = new Rectangle((int)chutePosition.X , (int)chutePosition.Y , (int)chuteTexture.Width, (int)chuteTexture.Height);


        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            spriteBatch.Begin();
            spriteBatch.Draw(chuteTexture,chutePosition,Color.White);
            spriteBatch.End();


        }
    }
}
