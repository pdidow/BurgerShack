﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
   
        public enum OrderColor
        {
            Red,
            Green,
            Blue
            
        }
  
}
