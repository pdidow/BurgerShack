﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

using System;
using System.Collections.Generic;

using System.Linq;
using static BurgerShack.Game1;

namespace BurgerShack
{
    public class CustomerOrderBoard
    {
        //Background Graphic for the orderboard
        private Texture2D customerOrderBoardTexture;
        private Texture2D rowTexture;
        private Vector2 rowPosition;
        //This list contains the customer orders
        private List<CustomerOrder> customerOrderList;
        private Vector2 customerOrderBoardPosition;        
        private Rectangle customerOrderBoardCollisionBox;
        private Random randomSeed;
        private Color flashColor;
        private Color thecolor = new Color();
        private float orderFlashTimer;
        private float orderFlashtimerIntervalSeconds;
        public List<CustomerOrder> CustomerOrderList
        {
            get { return customerOrderList; }
            set { customerOrderList = value; }
        }
        public Rectangle CustomerOrderBoardCollisionBox
        {
            get { return customerOrderBoardCollisionBox; }
            set { customerOrderBoardCollisionBox = value; }
        }
       
        public Texture2D RowTexture
        {
            get { return rowTexture; }
            set { rowTexture = value; }
        }
        public Vector2 RowPosition
        {
            get { return rowPosition; }
            set { rowPosition = value; }
        }
        //Constructor
        public CustomerOrderBoard(Vector2 customerOrderBoardPosition)
        {
            this.customerOrderBoardPosition = customerOrderBoardPosition;
            customerOrderList = new List<CustomerOrder>();//MAX 3
            //Flash timers
            orderFlashTimer = 0.75f;
            orderFlashtimerIntervalSeconds =0.75f;//half a second interval to flash selected *matched* row

         }
        
        public void LoadContent(ContentManager Content)
        {

            customerOrderBoardTexture = Content.Load<Texture2D>("BackGround/customerOrderBoard");
            customerOrderBoardCollisionBox = new Rectangle((int)customerOrderBoardPosition.X, (int)customerOrderBoardPosition.Y, customerOrderBoardTexture.Width, customerOrderBoardTexture.Height);
            rowTexture = Content.Load<Texture2D>("CustomerOrderBoard/rowTexture");

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            //Draw the customer order board
            
            spriteBatch.Draw(customerOrderBoardTexture, customerOrderBoardPosition, Color.White);
            //Draw the row color
            foreach(CustomerOrder co in customerOrderList)
            {

                rowPosition = new Vector2(customerOrderBoardPosition.X, customerOrderBoardPosition.Y + 16 + rowTexture.Height * co.CustomerOrderNumber);
                if (orderFlashTimer < 0 && co.BMatchedToBurgerOrder==true)
                {
                    spriteBatch.Draw(rowTexture, rowPosition, Color.Black);
                }
                else
                {
                   
                        //set back to color.
                        switch (co.CustomerOrderColor)
                        {
                            case OrderColor.Red:
                                thecolor = Color.Red;
                                break;
                            case OrderColor.Green:
                                thecolor = Color.Green;
                                break;
                            case OrderColor.Blue:
                                thecolor = Color.Blue;
                                break;
                        default:
                            break;
                        }
                        spriteBatch.Draw(rowTexture, rowPosition, thecolor);
                }


            }
           

        }
        public void DrawAllCheckMarks(GameTime gameTime, SpriteBatch spriteBatch,ref List<CheckMark> checkMarkList)
        {
            //Draw all the checkmarks for the CustomerOrders
            foreach (CheckMark ck in checkMarkList)
            {
                ck.Draw(gameTime, spriteBatch);
            }
        }
        public void Update(GameTime gameTime, List<Belt> listBelts,ref Chef chef,List<BurgerOrder> listBurgerOrder,ref GameState gameState)
        {
            //FlashRows
            foreach (CustomerOrder customerOrder in customerOrderList)
            {
                if (customerOrder.BMatchedToBurgerOrder == true)
                {
                  
                    if (orderFlashTimer < 0)
                    {
                        //Every nSecondInterval set background to black
                        thecolor = Color.Black;
                        orderFlashTimer = orderFlashtimerIntervalSeconds;
                    }
                    else
                    {
                        //set back to color.
                        switch (customerOrder.CustomerOrderColor)
                        {
                            case OrderColor.Red:
                                thecolor = Color.Red;
                                break;
                            case OrderColor.Green:
                                thecolor = Color.Green;
                                break;
                            case OrderColor.Blue:
                                thecolor = Color.Blue;
                                break;
                        }
                       
                    }


                }
                else
                {
                    switch (customerOrder.CustomerOrderColor)
                    {
                        case OrderColor.Red:
                            thecolor = Color.Red;
                            break;
                        case OrderColor.Green:
                            thecolor = Color.Green;
                            break;
                        case OrderColor.Blue:
                            thecolor = Color.Blue;
                            break;
                    }
                }
                
            }
            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            //update the flash timer
            orderFlashTimer -= elapsed;
            //end flashRow


            bool breturn = false;
            if (this.customerOrderBoardCollisionBox.Intersects(chef.ChefCollisionRect)  && chef.BHasCompleteOrder==true)
            {
               

                //Check if we have a Completed bUrger that matches an Order on the customerOrderBoard.
                foreach (CustomerOrder customerOrder in customerOrderList)
                {
                    



                    //Match for items in listBurgerOrders
                    foreach (BurgerOrder burgerOrder in listBurgerOrder)
                    {


                        if (burgerOrder.BurgerOrderClosed == true)

                        {




                            //If return is true then burgerorder is good and we credit the score of the chef then remove the burgerorder. and the customerorder from the board.  if it is not valid then 
                            //penalize thje score or rating of the chef  and then remove the burger from the customer orderboard, and the burgerorder marked to be destroyed on next update
                            breturn = CheckCustomerOrderMatch(customerOrder.BurgerLayerList, burgerOrder.BurgerLayerList);
                            if (breturn == false)
                            {
                                //mark the burgerorder that the chef submitted for delete, then subtract scorew/rating.INVALID
                                burgerOrder.BurgerOrderFlaggedForDelete = true;
                                chef.BHasCompleteOrder = false;
                                chef.RemoveBurgerLayer();

                                chef.ScoreRating -= 5;


                            }
                            else//vALID
                            {
                                //THe burgerorder was correct. renove the customer order from the customerORderBoard.list and give points. Generate a new order

                                //Assign the burgerOrder to the chef and assign wrapper color.
                                chef.ChefCompleteBurgerOrder = burgerOrder;
                                //the customer order has been matched to the burgerorder. set this flag true so that we know to flash the color of this order to indicate the wrapping room color to matych
                                customerOrder.BMatchedToBurgerOrder = true;


                                //Switch to Wrapping Room

                                gameState = GameState.WrappingRoom;
                                chef.ChefPosition = new Vector2(320, 50);

                                chef.BHasCompleteOrder = false;
                                chef.RemoveBurgerLayer();
                                //Remove the customer order as it has been completed.
                                customerOrder.CustomerOrderFlaggedForDelete = true;
                                //Remove the burger order as it has been delivered
                                burgerOrder.BurgerOrderFlaggedForDelete = true;

                               
                               
                               
                                //Remove the checkmarks for the customer order as it is completed.

                                foreach (BurgerLayer bl in customerOrder.BurgerLayerList)
                                {
                                    switch (bl.BurgerLayerType)
                                    {
                                        case "tomato":
                                            //checkMarkList.Where(x=>x.LayerType==bl.BurgerLayerType) REMOVECHECKMARJ FROM LIST
                                            //checkMarkList.RemoveAll(x => x.LayerType == bl.BurgerLayerType);
                                            break;
                                        case "lettuce":
                                            break;
                                        case "onion":
                                            break;
                                        case "cheese":
                                            break;

                                        default:
                                            //ingore. for case of patty,toopbun,bottombun
                                            break;

                                    }
                                }

                                {

                                }



                            }





                        }
                    }

                }
            }
          


        }
        public bool CheckCustomerOrderMatch(List<BurgerLayer> customerOrderLayers, List<BurgerLayer> burgerOrderLayers)
        {



            // var test2NotInTest1 = customerOrderLayers.Where(t2 => !burgerOrderLayers.Any(t1 => customerOrderLayers.Contains(t1)));

            var varCustomerLayers = from s in customerOrderLayers
                          select new { LayerName = s.BurgerLayerType };
            var varBurgerOrderLayers = from s in burgerOrderLayers
                                     select new { LayerName = s.BurgerLayerType };
            bool equal = varCustomerLayers.Equals(varCustomerLayers);




            return equal;
        }

        
    }
}
