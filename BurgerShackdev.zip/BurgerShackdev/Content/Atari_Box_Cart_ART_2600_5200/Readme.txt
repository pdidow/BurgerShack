The following fonts are very close matches to those used by Atari on their 2600 and 5200 cartridges and boxes. To download a font, click on the appropriate sample. We also have Macintosh versions of the fonts available, which you can find below each sample.

Ergoe: Used on Atari 2600 Silver and 5200 Silver Labels

PC Version
Macintosh Version

HammerFat: Used on Atari 2600 Text Labels

PC Version
Macintosh Version

MumboSSK: Used on Atari 2600 Picture Labels

PC Version
Macintosh Version

Eras Demi ITC: Used on Silver Atari 2600 and 5200 boxes

PC Version
Macintosh Version

Eras Light ITC: Used on Silver Atari 2600 and 5200 boxes

PC Version
Macintosh Version

Thanks to Bob DeCrescenzo who provided us with the PC fonts, and to Sarah Szefer for sending us Macintosh versions of the fonts.