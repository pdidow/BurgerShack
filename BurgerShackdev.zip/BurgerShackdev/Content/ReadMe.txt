Soundtracks downloaded from https://www.vgmusic.com/music/console/atari/2600/
Under the heading PressureCooker