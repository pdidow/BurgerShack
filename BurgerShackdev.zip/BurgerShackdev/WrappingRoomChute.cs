﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace BurgerShack
{
    public class WrappingRoomChute
    {
        private Vector2 chutePosition;
        private Rectangle chuteCollisionBox;
        private Rectangle chuteTargetCollisionBox;
        //private Color chuteColor;
        private Texture2D chuteTexture;
        private OrderColor chuteColor;
        private const int chuteWidth = 98;
        private const int chuteHeight = 236;
        private List<BurgerOrder> chuteBurgerOrders;
        public List<BurgerOrder> ChuteBurgerOrders
        {
            get { return chuteBurgerOrders; }
            set { chuteBurgerOrders = value; }
        }


        public Rectangle ChuteTargetCollisionBox
        {
            get { return chuteTargetCollisionBox; }
            set { chuteTargetCollisionBox = value; }
        }
        public Vector2 ChutePosition
        {
            get { return chutePosition; }
            set { chutePosition = value; }
        }
        public Rectangle ChuteCollisionBox
        {
            get { return chuteCollisionBox; }
            set { chuteCollisionBox = value; }
        }
        public OrderColor ChuteColor
        {
            get { return chuteColor; }
            set { chuteColor = value; }
        }
        public Texture2D ChuteTexture
        {
            get { return chuteTexture; }
            set { chuteTexture = value; }
        }
        //Default COnstructor
        public WrappingRoomChute(Vector2 position, OrderColor color)
        {
            chutePosition = position;
            chuteCollisionBox = new Rectangle((int)position.X, (int)position.Y, chuteWidth, chuteHeight);
            chuteBurgerOrders = new List<BurgerOrder>();
            chuteColor = color;

        }
        public void LoadContent(ContentManager Content)
        {
            chuteTexture = Content.Load<Texture2D>("WrappingRoom/wrappingChute");
            chuteTargetCollisionBox = new Rectangle((int)chutePosition.X, (int)chutePosition.Y + (int)chuteTexture.Height, chuteWidth, 1);
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            switch (chuteColor)
            {
                case OrderColor.Red:
                    spriteBatch.Begin();
                    spriteBatch.Draw(chuteTexture, chutePosition, null, Color.Red, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
                    spriteBatch.End();
                    break;
                case OrderColor.Green:
                    spriteBatch.Begin();
                    spriteBatch.Draw(chuteTexture, chutePosition, null, Color.Green, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
                    spriteBatch.End();
                    break;
                case OrderColor.Blue:
                    spriteBatch.Begin();
                    spriteBatch.Draw(chuteTexture, chutePosition, null, Color.Blue, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
                    spriteBatch.End();
                    break;

            }

        }


    }
}