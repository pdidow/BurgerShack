﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class BurgerLayer
    {
        private string burgerLayerType;
        private Texture2D burgerLayerTexture;
        private float burgerLayerWidth;
        private float burgerLayerHeight;
        private float fLayerZoom;
        private int burgerLayernumber;
        private Vector2 burgerLayerPosition;
        private bool bRejected;
        private bool bRecovered;
        private Rectangle burgerLayerRectangle;
        private float layerMovermentSpeed;
        private const float MOVEMENTSPEED = 5f;
        public string BurgerLayerType
        {
            get { return burgerLayerType; }
            set { burgerLayerType = value; }
        }
        public float BurgerLayerWidth
        {
            get { return burgerLayerWidth; }
            set { burgerLayerWidth = value; }
        }
        public float BurgerLayerHeight
        {
            get { return burgerLayerHeight; }
            set { burgerLayerHeight = value; }
        }
       
        public Texture2D BurgerLayerTexture
        {
            get { return burgerLayerTexture; }
            set { burgerLayerTexture = value; }
        }
        public int LayerNumber
        {
            get { return burgerLayernumber; }
            set { burgerLayernumber = value; }
        }
        public Vector2 BurgerLayerPosition
        {
            get { return burgerLayerPosition; }
            set { burgerLayerPosition = value; }
        }

        public bool BRejected
        {
            get { return bRejected; }
            set { bRejected = value; }
        }
        public bool BRecovered
        {
            get { return bRecovered; }
            set { bRecovered = value; }
        }
        public Rectangle BurgerLayerRectangle
        {
            get { return burgerLayerRectangle; }
            set { burgerLayerRectangle = value; }
        }


        public float LayerMovermentSpeed
        {
            get { return layerMovermentSpeed; }
            set { layerMovermentSpeed = value; }
        }
        public BurgerLayer(string burgerLayerType)
        {
            this.burgerLayerType = burgerLayerType;
            fLayerZoom = 0.25f;
            layerMovermentSpeed = MOVEMENTSPEED;
            bRecovered = false;

           
        }
        public BurgerLayer(string burgerLayerType,Vector2 position)
        {
            this.burgerLayerType = burgerLayerType;
            this.BurgerLayerPosition = position;
            fLayerZoom = 0.25f;
            layerMovermentSpeed = MOVEMENTSPEED;
            bRecovered = false;

        }
        public BurgerLayer(int burgerayernumber)
        {
            this.burgerLayernumber = burgerayernumber;
            layerMovermentSpeed = MOVEMENTSPEED;
            bRecovered = false;

        }
        public BurgerLayer(string burgerLayerType,int layernumber,Vector2 position)
        {
            this.burgerLayerType = burgerLayerType;
            this.burgerLayernumber = layernumber;
            fLayerZoom = 0.25f;
            burgerLayerPosition =position;
            layerMovermentSpeed = MOVEMENTSPEED;
            bRecovered = false;

        }
        public BurgerLayer(string burgerLayerType, int layernumber)
        {
            this.burgerLayerType = burgerLayerType;
            this.burgerLayernumber = layernumber;
            fLayerZoom = 0.25f;
            layerMovermentSpeed = MOVEMENTSPEED;
            bRecovered = false;

        }


        public void Draw(GameTime gameTime, SpriteBatch spriteBatch,Vector2 position)
        {
            //Draw the burgerLayerTexture on the chef player.
            //draw burger component
            burgerLayerPosition = position;
            spriteBatch.Draw(burgerLayerTexture, position, null, Color.White, 0f,
            Vector2.Zero, fLayerZoom, SpriteEffects.None, 0f);

           

        }
        //Overload the Draw function for the Zoom Variable
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch, Vector2 position,float fLayerZoom)
        {
            //Draw the burgerLayerTexture on the chef player.
            //draw burger component
            burgerLayerPosition = position;
            spriteBatch.Draw(burgerLayerTexture, burgerLayerPosition, null, Color.White, 0f,
            Vector2.Zero, fLayerZoom, SpriteEffects.None, 0f);

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch, Vector2 position, float fLayerZoom, OrderColor color, Texture2D coloredburgerLayerTexture, bool bDrawWrapper)
        {
            if (bDrawWrapper == false)
            {

                //Draw the burgerLayerTexture on the chef player.
                //draw burger component
                burgerLayerPosition = position;
                spriteBatch.Draw(burgerLayerTexture, burgerLayerPosition, null, Color.White, 0f, Vector2.Zero, fLayerZoom, SpriteEffects.None, 0f);
            }
            else
            {
                //Convert to Xna.Color
                Color xnaColor = new Color();
                switch (color)
                {
                    case OrderColor.Red:
                        xnaColor = Color.Red;
                        break;
                    case OrderColor.Green:
                        xnaColor = Color.Green;
                        break;
                    case OrderColor.Blue:
                        xnaColor = Color.AliceBlue;
                        break;
                    default:
                        xnaColor = Color.Blue;
                        break;




                }
                burgerLayerPosition = position;
                spriteBatch.Draw(coloredburgerLayerTexture, burgerLayerPosition, null, xnaColor, 0f, Vector2.Zero, fLayerZoom, SpriteEffects.None, 0f);


            }
        }
        public void Update(GameTime gameTime, Vector2 chefposition,List<Chute> chuteList)
        {
            if (bRejected == true)
            {
                //Check for Collision with chute of type of the burgerLayer
                foreach (Chute chute in chuteList)
                {
                    if (chute.ChuteRectangle.Intersects(burgerLayerRectangle) && chute.ChuteName==burgerLayerType)
                    {
                        //BurgerComponent has been recovered.
                        bRecovered = true;
                    }
                }

                
            }
            else if (bRejected==false)
            {
                burgerLayerPosition = chefposition;
            }
            burgerLayerRectangle = new Rectangle((int)burgerLayerPosition.X, (int)burgerLayerPosition.Y, (int)burgerLayerWidth, (int)burgerLayerHeight);
        }
     
        public void LoadContent(ContentManager Content,string burgerLayerType)
        {
            switch (burgerLayerType) 
                {
                case "patty":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/burgerPatty");
                    break;
                case "onion":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/OnionLayer");
                    break;
                case "cheese":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/CheeseLayer");
                    break;
                case "lettuce":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/lettuceLayer");
                    break;
                case "tomato":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/tomatoLayer");
                    break;
                case "topbun":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/topbun");
                    break;
                case "bottombun":
                    burgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/bottombun");
                    break;

            }
            burgerLayerWidth = burgerLayerTexture.Width;
            burgerLayerHeight = burgerLayerTexture.Height;

        }
    }
}
