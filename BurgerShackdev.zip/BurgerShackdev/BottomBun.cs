﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class BottomBun
    {
        private Texture2D bottomBunTexture;
        private Vector2 bottomBunPosition;
        private Rectangle bottomBunCollisionBox;
        private int bottomBunWidth;
        private int bottomBunHeight;
        private float fBottomBunZoom;
        private BottomBunState bbState;
        public enum BottomBunState { OnBelt, Falling, OnPlatter };
        private float fxmovementSpeed;
        private float fymovementSpeed;
        private bool bFlaggedDelete;
        public int BottomBunWidth
        {
            get { return bottomBunWidth; }
            set { bottomBunWidth = value; }
        }
        public int BottomBunHeight
        {
            get { return bottomBunHeight; }
            set { bottomBunHeight = value; }
        }
        public Rectangle BottomBunCollisionBox
        {
            get { return bottomBunCollisionBox; }
            set { bottomBunCollisionBox = value; }
        }

        public BottomBunState BBState
        {
            get { return bbState; }
            set { bbState = value; }
        }
        public float fXMovementSpeed
        {
            get { return fxmovementSpeed; }
            set { fxmovementSpeed = value; }
        }
        public float fYMovementSpeed
        {
            get { return fxmovementSpeed; }
            set { fxmovementSpeed = value; }
        }
        public bool BFlaggedDelete
        {
            get { return bFlaggedDelete; }
            set { bFlaggedDelete = value; }
        }
        //Constructors
        public BottomBun()
        {
            bbState=BottomBunState.OnPlatter;
        }
        public BottomBun(Vector2 startPosition)
        {
            bottomBunPosition = new Vector2(startPosition.X, startPosition.Y);
            bottomBunCollisionBox = new Rectangle((int)(bottomBunPosition.X) , (int)(bottomBunPosition.Y) , bottomBunWidth, (int)(bottomBunHeight));

            fBottomBunZoom = 0.5f;
            fxmovementSpeed = 2f;
            fymovementSpeed = 1.1f;
            //Set the initial state of the bottomBun patty
            bbState =BottomBunState.Falling;
        }
        public void LoadContent(ContentManager Content)
        {

            bottomBunTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/bottombun");
            bottomBunWidth = (int)(bottomBunTexture.Width * fBottomBunZoom);
            bottomBunHeight = (int)(bottomBunTexture.Height * fBottomBunZoom); ;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(bottomBunTexture, bottomBunPosition, null, Color.White, 0f,
            Vector2.Zero, fBottomBunZoom, SpriteEffects.None, 0f);
        }
        public void Update(GameTime gameTime, List<Belt> listBelts)
        {

            //In this update we move the burger patty to the left until it is no longer in contact with the conveyer belt up top, falls to the bottom on bun,then it falls to the burger assembly
            switch (bbState)
            {
                case BottomBunState.Falling:

                    bottomBunPosition = new Vector2(bottomBunPosition.X, bottomBunPosition.Y + 1*fYMovementSpeed);
                    break;
                case BottomBunState.OnBelt:
                    bottomBunPosition = new Vector2(bottomBunPosition.X - 1*fxmovementSpeed, bottomBunPosition.Y);
                    break;
                //Placed on Converyor
                case BottomBunState.OnPlatter:
                    bottomBunPosition = new Vector2(bottomBunPosition.X, bottomBunPosition.Y + 1);
                    break;

            }
           
            
            //Check for collsion of the patty with the belts
            foreach (Belt belt in listBelts)
            {
                if (bottomBunCollisionBox.Intersects(belt.BeltCollisionBox))


                {
                    //Move left if on belt.
                    bbState = BottomBunState.OnBelt;
                    //Let's just break out of the loop!
                    break;

                }
                else
                {

                    bbState = BottomBunState.Falling;

                }

            }
            bottomBunCollisionBox = new Rectangle((int)(bottomBunPosition.X), (int)(bottomBunPosition.Y), bottomBunWidth, (int)(bottomBunHeight));
            
        }
    
}
}
