﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
namespace BurgerShack
{
    public class Explosion
    {
        private Vector2 explosionPosition;
        private SpriteAnimation explosionSpriteAnimation;//Contains our animation sequences
        private float explosionWidth;
        private float explosionHeight;
        private float fExplosionScale;
        private bool bFlaggedForDelete;
        private const int  NUMBEROFFRAMES= 5;

        public enum ExplosionType { explodetomato,explodelettuce,explodeonion,explodecheese,explodetopbun};
        private ExplosionType _explosionType;
        public bool BFlaggedForDelete
        {
            get { return bFlaggedForDelete; }
            set { bFlaggedForDelete = value; }
        }
        public SpriteAnimation ExplosionSpriteAnimation
        {
            get { return explosionSpriteAnimation; }
            set { explosionSpriteAnimation = value; }
        }


        public ExplosionType _ExplosionType
        {
            get { return _explosionType; }
            set { _explosionType = value; }
        }
        public Explosion(Vector2 position,ExplosionType explosionType)
        {
            this.explosionPosition = position;
            this._explosionType = explosionType;
            this.explosionWidth = 32;
            this.explosionHeight =32;
            this.fExplosionScale = 1f;//not yet utilized.
            this.bFlaggedForDelete = false;

        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            explosionSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Explosion/ExplosionSheet"), 6, 5); //#frames, # animtions
            explosionSpriteAnimation.FramesPerSecond = 15;

            ani.IsLooping =false;
            explosionSpriteAnimation.AddAnimation("explodetomato", 1, 6, ani.Copy());
            explosionSpriteAnimation.AddAnimation("explodelettuce", 2, 6, ani.Copy());
            explosionSpriteAnimation.AddAnimation("explodeonion", 3, 6, ani.Copy());
            explosionSpriteAnimation.AddAnimation("explodecheese", 4, 6, ani.Copy());
            explosionSpriteAnimation.AddAnimation("explodetopbun", 5, 6, ani.Copy());
            explosionSpriteAnimation.Animation = _explosionType.ToString();
            explosionSpriteAnimation.Position = explosionPosition;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (explosionSpriteAnimation.Animation != null && bFlaggedForDelete==false)
            {
                explosionSpriteAnimation.Draw(spriteBatch,1f);
            }
            if (explosionSpriteAnimation.FrameIndex>=NUMBEROFFRAMES)
            {
                bFlaggedForDelete = true;
            }





        }
        public void Update(GameTime gameTime)
        {
            explosionSpriteAnimation.Update(gameTime);
           
            
        }
    }
}
