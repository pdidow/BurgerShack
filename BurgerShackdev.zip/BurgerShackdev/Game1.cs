﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;

namespace BurgerShack
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Color backgroundColor;
        private Chef chef;//Creat the player
        private Vector2 startPosition;  //Chef's starting position on screen.
        //Declare the customerOrderBoard
        private CustomerOrderBoard customerOrderBoard;
        //Declare Texture2D objects
        private Texture2D backGroundTexture;
        private Texture2D wrappingRoomBackGroundTexture;
        private Texture2D titleScreenBackGroundTexture;

        //Declare List of Chutes
        private List<Chute> chuteList;
        //Chutes
        private Chute onionChute;
        private Chute cheeseChute;
        private Chute lettuceChute;
        private Chute tomatoChute;
        private Chute topbunChute;
        //Declare thhe Conveyor Wall
        private ConveyorWall conveyor;
        //Declare the list of Belts
        private List<Belt> beltList;
        private List<Explosion> explosionList;
        private Random rand;
        private int randBurgerComponent;
        //list of burger components currectly activly flying on screen
        private List<BurgerComponent> listBurgerComponent;
        private float burgerComponentTimer;

        float burgerComponenttimerIntervalSeconds;
        float broilerTimerIntervalSec;
        float bottomBunTimerIntervalSec;
        float burgerOrderPlatterReleaseTimerIntervalSec;
        //Flamer Broiler stuff
        private FlameBroiler flames;
        private float broilerTimer;
        private float burgerOrderPlatterReleaseTimer;

        //Bottom Bun Pooper stuff
        private BottomBunPooper bottomBunPooper;
        private float bottomBunPooperTimer;

        //Create the conveyor belt cogs
        private Cog topLeftCog;
        private Cog topRightCog;
        private Cog bottomLeftCog;
        private Cog bottomRightCog;
        //CogList
        private List<Cog> CogList;
        private bool bInGameMusicStarted = false;
        private bool bGameStartMusicStarted = false;
        private bool bGameOverMusicStarted = false;
        //Sounds
        private SoundEffect placeItemSound;
        private SoundEffect returnSound;
        private SoundEffect successSound;
        private int minNumberOfBurgerOrders;//This should always be 3 - as there are 3 orders on the CustomerOrderBoard.
        //Music
        Song gameStartSong;
        Song inGameSong;
        Song startGameSong;
        Song gameOverSong;
        private List<BurgerOrder> listBurgerOrders_conveyor;//Orders on the conveyor wall
        private int maxCondiments;//max number of layers for the customer order in the current wave of the game
        private int minCondiments;//min number of layers for the customer order int the current wave of the game
        private KeyboardState pastKey;
        Rectangle boundryRect;
        Vector2 boundry;
        //GameState
        public enum GameState
        {
            TitleScreen, GameStarting, GameStarted, GameOver, WrappingRoom

        }
        GameState gameState;
        private GraphicsDevice graphicsDevice;
        private WrappingRoom wrappingRoom;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.PreferredBackBufferWidth = 640;
            _graphics.PreferredBackBufferHeight = 480;
            _graphics.IsFullScreen = true;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            backgroundColor = Color.Black;
            _graphics.ApplyChanges();
            minNumberOfBurgerOrders = 3;
           

        }

        protected override void Initialize()
        {
            startPosition = new Vector2(_graphics.PreferredBackBufferWidth / 2 + 16, _graphics.PreferredBackBufferHeight / 2 + 32);
            customerOrderBoard = new CustomerOrderBoard(new Vector2(250, 414));
            customerOrderBoard.LoadContent(Content);
            //TESTING CHECKMARK, crearew only one and thendraw. remove this test code.
            //CheckMark ckd =new CheckMark(new Vector2(332,460));
            //ckd.LoadContent(Content);
            //customerOrderBoard.GetRandomCondiment();
            //customerOrderBoard.AddCheckMarkToCustomerOrderList(ckd);
            /////////////////////////////////////////////////////////////
            //Creat Chef object
            chef = new Chef(startPosition);
            //ChuteList
            chuteList = new List<Chute>();
            //Chutes
            onionChute = new Chute("onion");
            cheeseChute = new Chute("cheese");
            lettuceChute = new Chute("lettuce");
            tomatoChute = new Chute("tomato");
            topbunChute = new Chute("topbun");

            chuteList.Add(onionChute);
            chuteList.Add(cheeseChute);
            chuteList.Add(lettuceChute);
            chuteList.Add(tomatoChute);
            chuteList.Add(topbunChute);
            //Initialize beltlist
            beltList = new List<Belt>();
            //As there are only 2 belts, lets add them right here.
            beltList.Add(new Belt(Belt.beltType.top, new Vector2(285, 126), Content));
            beltList.Add(new Belt(Belt.beltType.bottom, new Vector2(193, 155), Content));

            //List of Active burger componets
            listBurgerComponent = new List<BurgerComponent>();
            burgerComponentTimer = 3;//Timer for burger component generator
            burgerComponenttimerIntervalSeconds = 3;
            //Create the conveyor wallaasdads
            conveyor = new ConveyorWall();
            conveyor.LoadContent(Content);
            listBurgerOrders_conveyor = new List<BurgerOrder>();
            //Create some burger new empty burger orders on conveyor
            for (int x = 0; x < minNumberOfBurgerOrders; x++)
            {
                listBurgerOrders_conveyor.Add(new BurgerOrder(new Vector2(conveyor.WallPosition.X + 8, 140 + x * 20)));
                listBurgerOrders_conveyor[x].LoadContent(Content);

            }
            //initialize explosionlist
            explosionList = new List<Explosion>();
            //Initialize Flame Broiler and Timer
            flames = new FlameBroiler();
            broilerTimer = 7;
            broilerTimerIntervalSec = 7;
            //Initialize the BottomBunPooper and timer
            bottomBunPooper = new BottomBunPooper();
            bottomBunPooperTimer = 7;
            bottomBunTimerIntervalSec = 7;
            //Initialize BurgerOrderPlatterTimer to move the platters on the oonveyorwall
            burgerOrderPlatterReleaseTimer = 8;//set this value and the one below it to the same values but this is delay in seconds for the platters
            burgerOrderPlatterReleaseTimerIntervalSec = 8;
            //Initialize Cogs. Set position and Direction.
            topLeftCog = new Cog("left", new Vector2(280, 135));
            topLeftCog.LoadContent(Content);

            topRightCog = new Cog("left", new Vector2(352, 135));
            topRightCog.LoadContent(Content);

            bottomLeftCog = new Cog("left", new Vector2(318, 162));
            bottomLeftCog.LoadContent(Content);

            bottomRightCog = new Cog("left", new Vector2(445, 162));
            bottomRightCog.LoadContent(Content);

            CogList = new List<Cog>();
            CogList.Add(topLeftCog);
            CogList.Add(topRightCog);
            CogList.Add(bottomLeftCog);
            CogList.Add(bottomRightCog);
            minCondiments = 0;//for the first wave of the game, a customer can order a burger with no condiments (burgerlayer)
            maxCondiments = 1;//for the first wave of the game, a customer can order a max of 1 burgerlayer condiment

            //Initialize GameState. Initially should be 
            gameState = GameState.TitleScreen;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _graphics.GraphicsDevice.Clear(Color.Black);
            //Load Chef Content
            chef.LoadContent(Content);
            //Load flames content
            flames.LoadContent(Content);
            //Load the BottomBunPooper Content
            bottomBunPooper.LoadContent(Content);
            //Load Background
            backGroundTexture = Content.Load<Texture2D>("Background/background");
           
            titleScreenBackGroundTexture = Content.Load<Texture2D>("Title/GREEDYSBURGER_BOXARTv2");
            //Load Chute Content
            foreach (Chute chute in chuteList)
            {
                chute.LoadContent(Content, _graphics.PreferredBackBufferWidth);
            }
            //Load Music
            gameStartSong = Content.Load<Song>("Music/greedyburgershack_GameStart");
            inGameSong = Content.Load<Song>("Music/greedyburgershack_InGameSong");
            startGameSong = Content.Load<Song>("Music/greedyburgershack_GameStart");

            //Load Sound Effects
            placeItemSound = Content.Load<SoundEffect>("Audio/placeItemSound");
            returnSound = Content.Load<SoundEffect>("Audio/returnSound");
            successSound = Content.Load<SoundEffect>("Audio/successSound");


            //MediaPlayer.Play(inGameSong);
        }
        #region UpdateCode
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            //Create checkmarks

            foreach (CustomerOrder co in customerOrderBoard.CustomerOrderList)
            {
                int custorderNum = co.CustomerOrderNumber;
                if (co.CustomerOrderCheckMarkList == null)
                {
                    foreach (BurgerLayer bl in co.BurgerLayerList)
                    {

                        co.AddCheckMarkToCustomerOrderCheckMarkList(bl.BurgerLayerType, custorderNum, Content);


                    }

                }
                

            }
            //Play only at start of game and level.##STATE GAMESTARTING
            if (bGameStartMusicStarted == false && gameState == GameState.GameStarting)
            {
                //ChangeMusic(gameStartSong);
                ChangeMusic(startGameSong);
                bGameStartMusicStarted = true;


            }

            //Play until game over. Looping.##STATE GAMESTARTED
            if (bInGameMusicStarted == false && gameState == GameState.GameStarted)
            {
                //ChangeMusic(inGameSong);
                ChangeMusic(startGameSong);
                MediaPlayer.IsRepeating = true;
                bInGameMusicStarted = true;
            }

            switch (gameState)
            {
                case GameState.WrappingRoom:
                    if (wrappingRoom == null)
                    {
                        //Find the completed burgerorder the chef is carrying and pass it
                        foreach (BurgerOrder bo in listBurgerOrders_conveyor)
                        {
                            if (bo.BurgerOrderDropInChute==true)
                            {
                                wrappingRoom = new WrappingRoom(bo,chef.ChefPosition,Content);
                                wrappingRoom.LoadContent(Content);
                            }
                        }
                       
                       
                    }
                    //Update the player
                   
                    UpdatePlayer(gameTime);
                    //Update the burgerorder through the wrappingRoom Update. On press of space we will drop the burger.
                    if (wrappingRoom != null)
                    {
                        
                        wrappingRoom.Update(gameTime,ref chef,ref gameState);
                    }
                    //UpdateBurgerOrders(gameTime);
                    break;
                case GameState.GameStarting:
                    //Update the player
                    UpdatePlayer(gameTime);
                    //Update the timers
                    UpdateTimers(gameTime);
                    //Update the customerOrders/CustomerORder Board
                    //Create a customer order if we do not have the 3 on the board.
                    UpdateCustomerOrders(gameTime);
                    //Update the Burger Components in list
                    UpdateBurgerComponents(gameTime);
                    //Clean up the CustomerOrders thet are flagged
                    UpdateFlaggedForDelete(gameTime);
                    //Update the BottomBunpooper
                    UpdateBottomBunPooper(gameTime);
                    //Update the flameBroiler
                    UpdateFlameBroiler(gameTime);
                    //Update the BottomBun list
                    UpdateBottomBunList(gameTime);
                    //Update the Burger Pattys
                    UpdatePattyList(gameTime);
                    //Update the bottombun pooper
                    //if (customerOrderBoard.CustomerOrderList.Count > 0)
                    //{
                    bottomBunPooper.Update(gameTime);
                    //}
                    //Update the explosions
                    UpdateWastedExplosions(gameTime);

                    //Update the flames animation
                    UpdateFlamesAnimation(gameTime);

                    //Update the burgerOrders                
                    if (burgerOrderPlatterReleaseTimer < 0  /*&& customerOrderBoard.CustomerOrderList.Count > 0*/)
                    {
                        UpdateBurgerOrders(gameTime);
                    }
                    
                    //Update the belts
                    UpdateBelts(gameTime);
                    //Update the Cogs
                    UpdateCogs(gameTime);

                    //Update the CustomerOrderBoard
                    customerOrderBoard.Update(gameTime, beltList, ref chef, listBurgerOrders_conveyor, ref gameState);
                    break;

            }
           
            if (gameState == GameState.TitleScreen)
            {
                //check for input to start the game.
                if (Keyboard.GetState().IsKeyDown(Keys.Space) && pastKey.IsKeyUp(Keys.Space))
                {

                    gameState = GameState.GameStarting;

                }

            }
            pastKey = Keyboard.GetState();
            base.Update(gameTime);
        }
        private void UpdateTimers(GameTime gameTime)
        {
            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (startGameSong.Position.TotalSeconds >= 8)
            {



                //update the bottom bun pooper timer
                bottomBunPooperTimer -= elapsed;
                //update the burger component timer
                burgerComponentTimer -= elapsed;
                //update the flame broiler timer
                broilerTimer -= elapsed;
                //Update the burgerOrderPlatterTimer
                burgerOrderPlatterReleaseTimer -= elapsed;
            }
        }
        private void UpdateFlamesAnimation(GameTime gameTime)
        {
            flames.Update(gameTime);
        }
        private void UpdateWastedExplosions(GameTime gameTime)
        {
            foreach (Explosion explosion in explosionList)
            {
                explosion.Update(gameTime);
            }
        }
        
        private void UpdateBurgerOrders(GameTime gameTime)
        {

            bool breturn = false;
            foreach (BurgerOrder bo in listBurgerOrders_conveyor)
            {

                breturn = bo.Update(gameTime, chef.ChefCollisionRect, chef.ChefBurgerLayer, conveyor.WallCollisionRect,customerOrderBoard.CustomerOrderList);

                if (breturn)
                {
                    //add 10 to score if this is the first layer added
                    if (bo.BurgerLayerList.Count == 3)
                    {
                        chef.Score += 10;
                    }
                    //remove chef burger layer
                    chef.RemoveBurgerLayer();
                }

                //Bottom Bun (from the converyor) collides with the burgerplatter
                foreach (BottomBun bb in bottomBunPooper.BottomBunList)
                {
                    if (bb.BottomBunCollisionBox.Intersects(bo.BurgerOrderCollisionRect))
                    {


                        //Remove the bottomBun from the BottomBunPooper's BottomBUnList,
                        //then add a new layer of this type (bottomBUn) to the BurgerOrder, in the bottom element of list.
                        //bb.MarkforDeletion=true
                        //Only add the bottom bun if one has not been added before!
                        var item = bo.BurgerLayerList.Find(x => x.BurgerLayerType == "bottombun");
                        if (item == null)
                        {
                            BurgerLayer bl = new BurgerLayer("bottombun", 1, chef.ChefPosition);
                            bl.LoadContent(Content, "bottombun");
                            bo.BurgerLayerList.Add(bl);
                            bb.BFlaggedDelete = true;
                        }






                    }
                    //Upfste the BottomBunlist
                    bb.Update(gameTime, beltList);
                }
                //Now check if one of the pattys has collided with the burgerorder
                foreach (BurgerPatty bp in flames.PattyList)
                {
                    if (bp.BurgerPattyCollisionBox.Intersects(bo.BurgerOrderCollisionRect))
                    {
                        //Remove the bottomBun from the BottomBunPooper's BottomBUnList,
                        //then add a new layer of this type (bottomBUn) to the BurgerOrder, in the bottom element of list.
                        //bb.MarkforDeletion=true

                        var item = bo.BurgerLayerList.Find(x => x.BurgerLayerType == "patty");
                        if (item == null)
                        {
                            BurgerLayer bl = new BurgerLayer("patty", 2);
                            bl.LoadContent(Content, "patty");
                            bo.BurgerLayerList.Add(bl);
                            bp.BFlaggedDelete = true;
                        }




                    }
                    //Upfste the bp
                    bp.Update(gameTime, beltList);
                }


            }
        }
        private void UpdatePattyList(GameTime gameTime)
        {
            foreach (BurgerPatty bp in flames.PattyList)
            {
                //if ( customerOrderBoard.CustomerOrderList.Count > 0)
                //{
                bp.Update(gameTime, beltList);
                //    }
            }
        }
        private void UpdateBelts(GameTime gameTime)
        {
            foreach (Belt belt in beltList)
            {
                belt.Update(gameTime);
            }
        }
        private void UpdateCogs(GameTime gameTime)
        {
            foreach (Cog cog in CogList)
            {
                cog.Update(gameTime);
            }
        }
        private void UpdateBottomBunList(GameTime gameTime)
        {
            foreach (BottomBun bb in bottomBunPooper.BottomBunList)
            {
                //if ( customerOrderBoard.CustomerOrderList.Count > 0)
                //{
                //    bb.Update(gameTime, beltList);
                //}
                bb.Update(gameTime, beltList);
            }
        }
        private void UpdateFlameBroiler(GameTime gameTime)
        {
            if (broilerTimer < 0 /*&& customerOrderBoard.CustomerOrderList.Count > 0*/)
            {
                flames.AddBurgerPatty(Content);
                broilerTimer = broilerTimerIntervalSec;
            }
        }
        private void UpdateBottomBunPooper(GameTime gameTime)
        {
            if (bottomBunPooperTimer < 0  /*&& customerOrderBoard.CustomerOrderList.Count>0*/)
            {
                bottomBunPooper.AddBottomBun(Content, new Vector2(bottomBunPooper.BottomBunPooperPosition.X - bottomBunPooper.BottomBunPooperWidth / 2 + 8, bottomBunPooper.BottomBunPooperPosition.Y));
                bottomBunPooperTimer = bottomBunTimerIntervalSec;
            }

        }
        private void UpdateFlaggedForDelete(GameTime gameTime)
        {
            var foundDeleteCustomerOrder = customerOrderBoard.CustomerOrderList.Find(x => x.CustomerOrderFlaggedForDelete == true);
            if (foundDeleteCustomerOrder != null)
            {
                customerOrderBoard.CustomerOrderList.Remove(foundDeleteCustomerOrder);

            }
            //clean up the BUrgerOrders flagged for delete
            var foundDeleteBurgerOrder = listBurgerOrders_conveyor.Find(x => x.BurgerOrderFlaggedForDelete == true);
            if (foundDeleteBurgerOrder != null)
            {
                listBurgerOrders_conveyor.Remove(foundDeleteBurgerOrder);
                chef.BHasCompleteOrder = false;
            }
            //Clean up the BottomBunPooper Buns we flagged for delete.
            var foundDeleteBun = bottomBunPooper.BottomBunList.Find(x => x.BFlaggedDelete == true);
            if (foundDeleteBun != null)
            {
                bottomBunPooper.BottomBunList.Remove(foundDeleteBun);
            }


            //Clean up the BurgerPattys from the BurgerPatty list belonging to the FlameBroiler
            var foundDeleteBurgerPatty = flames.PattyList.Find(x => x.BFlaggedDelete == true);
            if (foundDeleteBurgerPatty != null)
            {
                flames.PattyList.Remove(foundDeleteBurgerPatty);
            }
        }
        private void UpdateBurgerComponents(GameTime gameTime)
        {
            if (burgerComponentTimer < 0/* && customerOrderBoard.CustomerOrderList.Count>0*/)
            {
                //Every nSecondInterval Generate a random Burger Component
                listBurgerComponent.Add(GenerateRandomBurgerComponent());
                burgerComponentTimer = burgerComponenttimerIntervalSeconds;
            }

            foreach (BurgerComponent bc in listBurgerComponent)
            {
                bc.Update(gameTime, boundry);
                //Check if the burger component hits the conveyor wall
                if (bc.BurgerComponentCollisionBox.Intersects(conveyor.WallCollisionRect))
                {
                    //Destroy this object! TODO bExplodeFlag AND animation!
                    bc.BDeleteFlag = true;
                    chef.ScoreRating -= 5;
                    returnSound.Play();
                    Explosion explode;
                    switch (bc.BurgerComponentType)
                    {
                        case "tomato":

                            explode = new Explosion(bc.BurgerComponentPosition, Explosion.ExplosionType.explodetomato);
                            //explode.ExplosionSpriteAnimation.Animation = "explodetomato";
                            explode.LoadContent(Content);
                            explosionList.Add(explode);
                            break;
                        case "lettuce":
                            explode = new Explosion(bc.BurgerComponentPosition, Explosion.ExplosionType.explodelettuce);
                            //explode.ExplosionSpriteAnimation.Animation = "explodelettuce";
                            explode.LoadContent(Content);
                            explosionList.Add(explode);
                            break;
                        case "onion":
                            explode = new Explosion(bc.BurgerComponentPosition, Explosion.ExplosionType.explodeonion);
                            //explode.ExplosionSpriteAnimation.Animation = "explodeonion";
                            explode.LoadContent(Content);
                            explosionList.Add(explode);
                            break;
                        case "cheese":
                            explode = new Explosion(bc.BurgerComponentPosition, Explosion.ExplosionType.explodecheese);
                            //explode.ExplosionSpriteAnimation.Animation = "explodecheese";
                            explode.LoadContent(Content);
                            explosionList.Add(explode);
                            break;
                        case "topbun":
                            explode = new Explosion(bc.BurgerComponentPosition, Explosion.ExplosionType.explodetopbun);
                            //explode.ExplosionSpriteAnimation.Animation = "explodetopbun";
                            explode.LoadContent(Content);
                            explosionList.Add(explode);
                            break;

                    }




                }

                if (bc.BurgerComponentCollisionBox.Intersects(chef.ChefCollisionRect) && chef.BHasCompleteOrder == false)//cant grab a new layer when have completed burger
                {
                    //Chef Caught the Burger Component!
                    //1. Create the burgerlayer of the type we intersected with, assign to chef. 
                    chef.ChefBurgerLayer = new BurgerLayer(bc.BurgerComponentType, chef.ChefPosition);
                    chef.ChefBurgerLayer.LoadContent(Content, chef.ChefBurgerLayer.BurgerLayerType);
                    //next remove the burgercomponent from the list !
                    bc.BDeleteFlag = true;
                    chef.Score += 5;
                }
            }

            //Remove explosions flagged for delete.
            var foundexp = explosionList.Find(x => x.BFlaggedForDelete == true);
            if (foundexp != null)
            {
                explosionList.Remove(foundexp);
            }
            //Clean up the burger components we flagged for deletion.
            var found = listBurgerComponent.Find(x => x.BDeleteFlag == true);
            if (found != null)
            {
                listBurgerComponent.Remove(found);
            }
        }
        private void  UpdateCustomerOrders(GameTime gameTime)
        {

            if (customerOrderBoard.CustomerOrderList.Count < minNumberOfBurgerOrders)
            {


                //Create a customer order as we do not have the minimum ie numberOfBurgerOrders
                CustomerOrder customerOrder = new CustomerOrder(customerOrderBoard.CustomerOrderList.Count);
                customerOrder.BottomBun = new BottomBun();//Create a dummy Bottom Bun for the customer order.
                customerOrder.BurgerOrderBurgerPatty = new BurgerPatty();//Create a dummy burger patty for the customer order.
                rand = new Random();
                int numberofLayers = rand.Next(minCondiments, maxCondiments + 1);//Random number of layers for the customer order between waves min and max setting.todo. 0 and 1 layers for now

                //How many layers in this customer order? starts with 0-1 for first level. set this in initialize of game. change at level complete.
                for (int x = 0; x < numberofLayers; x++)
                {
                    //Get a random layer string
                    string layer = customerOrder.GetRandomCondiment();
                    //Create a layer with that string
                    BurgerLayer bl = new BurgerLayer(layer);
                    bl.BurgerLayerType = layer;


                    //add the burgerlayer to the customer order
                    customerOrder.BurgerLayerList.Add(bl);
                    //add a checkmark of this type of burgerLayer to the checkmarklist for the customer order.
                    switch (layer)
                    {
                        case "tomato":
                            Vector2 checkMarkTomatoPosition = new Vector2(266, 420 + customerOrder.CustomerOrderNumber * 8);
                            CheckMark newTomatoCheck = new CheckMark(checkMarkTomatoPosition, "tomato");
                            newTomatoCheck.LoadContent(Content);
                            customerOrder.CustomerOrderCheckMarkList.Add(newTomatoCheck);

                            break;
                        case "lettuce":
                            Vector2 checkMarkLettucePosition = new Vector2(395, 420 + customerOrder.CustomerOrderNumber * 8);
                            CheckMark newLettuceCheck = new CheckMark(checkMarkLettucePosition, "lettuce");
                            newLettuceCheck.LoadContent(Content);
                            customerOrder.CustomerOrderCheckMarkList.Add(newLettuceCheck);
                            break;
                        case "onion":
                            Vector2 checkMarkOnionPosition = new Vector2(328, 420 + customerOrder.CustomerOrderNumber * 8);
                            CheckMark newOnionCheck = new CheckMark(checkMarkOnionPosition, "onion");
                            newOnionCheck.LoadContent(Content);
                            customerOrder.CustomerOrderCheckMarkList.Add(newOnionCheck);
                            break;
                        case "cheese":
                            Vector2 checkCheeseMarkPosition = new Vector2(462, 420 + customerOrder.CustomerOrderNumber * 8);
                            CheckMark newCheeseCheck = new CheckMark(checkCheeseMarkPosition, "cheese");
                            newCheeseCheck.LoadContent(Content);
                            customerOrder.CustomerOrderCheckMarkList.Add(newCheeseCheck);
                            break;


                    }
                    


                }
                //add the topbun to the order.
                customerOrder.BurgerLayerList.Add(new BurgerLayer("topbun"));
                //add the customer order to the customerOrderBoard
                customerOrderBoard.CustomerOrderList.Add(customerOrder);
            }
            
        }
        private void UpdatePlayer(GameTime gameTime)
        {
            //pass the border boundry of movement.  This should be the top right of the Grey ConveyorWall to right of screen to 
            boundryRect = new Rectangle((int)conveyor.WallPosition.X + (int)conveyor.WallTexture.Width, (int)conveyor.WallPosition.Y + (int)conveyor.WallTexture.Height, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            boundry = new Vector2(_graphics.PreferredBackBufferWidth - 16, _graphics.PreferredBackBufferHeight - 16);
            chef.Update(gameTime, boundry,chuteList,ref gameState, listBurgerOrders_conveyor);
        }
        #endregion
        private BurgerComponent GenerateRandomBurgerComponent()
        {
            // Select a random component
            rand = new Random();
            randBurgerComponent = rand.Next(5);
            string randomcomponent = "";
            switch (randBurgerComponent)
            {
                case 0:
                    randomcomponent = "onion";
                    break;
                case 1:
                    randomcomponent = "cheese";
                    break;
                case 2:
                    randomcomponent = "lettuce";
                    break;
                case 3:
                    randomcomponent = "tomato";
                    break;
                case 4:
                    randomcomponent = "topbun";
                    break;
            }
            BurgerComponent newBurgerComponent = new BurgerComponent(randomcomponent);
            newBurgerComponent.LoadContent(Content);
            return newBurgerComponent;
        }

        public void ChangeMusic(Song song)
        {
            // Isn't the same song already playing?
            if (MediaPlayer.Queue.ActiveSong != song)
                MediaPlayer.Play(song);
            if (gameState == GameState.GameStarting && song == startGameSong)
            {
                if (startGameSong.IsDisposed == true)
                    gameState = GameState.GameStarted;
            }

        }
        #region DrawCode
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(backgroundColor);

            // Draw BackGround
            switch (gameState)
            {
                case GameState.GameOver:
                    break;
                case GameState.GameStarted:
                    //Playing the game, Main Screen
                    _spriteBatch.Begin();
                    _spriteBatch.Draw(backGroundTexture, new Vector2(0, 50), Color.White);
                    _spriteBatch.End();
                    break;
                case GameState.WrappingRoom:
                    if (wrappingRoom != null)
                    {
                        wrappingRoom.Draw(gameTime, _spriteBatch);
                    }
                    else
                    {
                        wrappingRoom = new WrappingRoom(chef.ChefPosition,listBurgerOrders_conveyor,Content,chef.ChefCompleteBurgerOrder.BurgerrOrderColor);
                        wrappingRoom.LoadContent(Content);
                       
                    }
                    DrawPlayer(gameTime);
                    DrawChefConveyorBurgerOrder(gameTime,ref gameState);

                    break;
                case GameState.GameStarting:
                    //Playing the game, Main Screen
                    _spriteBatch.Begin();
                    _spriteBatch.Draw(backGroundTexture, new Vector2(0, 50), Color.White);
                    _spriteBatch.End();
                    //////
                    //Draw the customerOrderBoard (if three orders)               
                    DrawCustomerOrderBoard(gameTime, customerOrderBoard.CustomerOrderList);
                    // Draw Cogs
                    DrawCogs(gameTime);
                    // Draw Flames
                    DrawFlames(gameTime);
                    //Draw the BottomBunPooper
                    DrawBottomBunPooper(gameTime);
                    // Draw Chutes
                    DrawChutes(gameTime);
                    // Draw Conveyer Wall
                    DrawConveyor(gameTime);
                    //Draw the BurgerOrders that are on conveyor and on chef
                    DrawChefConveyorBurgerOrder(gameTime,ref gameState);
                    //Draw the explosions for wasted BurgerComponents
                    DrawWastedExplosions(gameTime);
                    //Draw the top and bottom belts.
                    DrawBelts(gameTime);
                    
                    //Draw each of the bottomBuns in the list
                    DrawBottomBuns(gameTime);
                    //Draw the burger pattys for flamebroiler
                    DrawPattyList(gameTime);
                    //Draw each of the BurgerComponents in the list
                    DrawBurgerComponents(gameTime);
                    //Draw the player and stats
                   
                    //Debuggging
                    //debug  chef.Burgerlayer collsion box
                    if (chef.ChefBurgerLayer != null)
                    {
                        //Texture2D _texture;
                        //_texture = new Texture2D(_graphics.GraphicsDevice, 1, 1);
                        //_texture.SetData(new Color[] { Color.Red });
                        //_spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                        //_spriteBatch.Draw(_texture, chef.ChefBurgerLayer.BurgerLayerRectangle, Color.White);
                        //_spriteBatch.End();
                      
                        DrawPlayer(gameTime);
                     
                    }
                    else
                    {
                        DrawPlayer(gameTime);
                    }
                    //debug  chutesr collsion box
                    //if (chuteList != null)
                    //{
                    //    foreach (Chute chute in chuteList)
                    //    {
                    //        Texture2D _texture;
                    //        _texture = new Texture2D(_graphics.GraphicsDevice, 1, 1);
                    //        _texture.SetData(new Color[] { Color.Red });
                    //        _spriteBatch.Begin();
                    //        _spriteBatch.Draw(_texture, chute.ChuteRectangle, Color.White);
                    //        _spriteBatch.End();
                    //    }
                    //}
                    //Draw the burgerLayer the player is carrying, if any
                    DrawChefBurgerLayer(gameTime);
                    base.Draw(gameTime);
          
                    break;
                case GameState.TitleScreen:
                    //Playing the game, Main Screen
                    _spriteBatch.Begin();
                    _spriteBatch.Draw(titleScreenBackGroundTexture, new Vector2(0, 50), Color.White);
                    _spriteBatch.End();

                    break;
            }
            if (gameState != GameState.TitleScreen)
            {
            }
        }
        protected void DrawWastedExplosions(GameTime gameTime)
        {
            foreach (Explosion ex in explosionList)
            {
                _spriteBatch.Begin();
                ex.Draw(gameTime, _spriteBatch);
                _spriteBatch.End();
            }
        }
        protected void DrawChefBurgerLayer(GameTime gameTime)
        {
            if (chef.ChefBurgerLayer != null)
            {
                switch (chef.ChefBurgerLayer.BRejected)
                {
                    case false:
                        _spriteBatch.Begin();
                        chef.DrawBurgerLayer(gameTime, _spriteBatch);
                        _spriteBatch.End();
                        break;
                    case true:
                        _spriteBatch.Begin();
                        chef.DrawBurgerLayer(gameTime, _spriteBatch,chef.ChefBurgerLayer.BRejected);
                        _spriteBatch.End();
                        break;

                }
                

            }
        }
        protected void DrawChefConveyorBurgerOrder(GameTime gameTime,ref GameState gameState)
        {
            switch (gameState)
            {
                case GameState.GameStarting:
                    foreach (BurgerOrder bo in listBurgerOrders_conveyor)
                    {
                        _spriteBatch.Begin();
                        if (bo.BurgerOrderClosed == false)
                        {
                            bo.Draw(gameTime, _spriteBatch);
                        }
                        else
                        {
                            chef.BHasCompleteOrder = true;
                            bo.DrawChefWithBurger(gameTime, _spriteBatch, ref chef,gameState);
                        }
                        _spriteBatch.End();
                    }
                    break;
                case GameState.WrappingRoom:
                    foreach (BurgerOrder bo in listBurgerOrders_conveyor)
                    {
                        _spriteBatch.Begin();
                        
                            chef.BHasCompleteOrder = true;
                            bo.DrawChefWithBurger(gameTime, _spriteBatch, ref chef,gameState);
                        
                        _spriteBatch.End();
                    }

                    break;


            }

           
        }
        protected void DrawConveyor(GameTime gameTime)
        {
            conveyor.Draw(gameTime, _spriteBatch);
        }
        protected void DrawCogs(GameTime gameTime)
        {
            _spriteBatch.Begin();
            foreach (Cog cog in CogList)
            {
                cog.Draw(gameTime, _spriteBatch);
            }
            _spriteBatch.End();
        }
        protected void DrawBottomBunPooper(GameTime gameTime)
        {
            _spriteBatch.Begin();
            bottomBunPooper.Draw(gameTime, _spriteBatch);
            _spriteBatch.End();
        }
        
        protected void DrawChutes(GameTime gameTime)
        {
            foreach (Chute chute in chuteList)
            {
                chute.Draw(gameTime, _spriteBatch);
            }
        }
        protected void DrawFlames(GameTime gameTime)
        {
            _spriteBatch.Begin();
            flames.Draw(gameTime, _spriteBatch);
            _spriteBatch.End();
        }
        protected void DrawBottomBuns(GameTime gameTime)
        {
            foreach (BottomBun bb in bottomBunPooper.BottomBunList)
            {
                _spriteBatch.Begin();
                bb.Draw(gameTime, _spriteBatch);
                _spriteBatch.End();
            }
        }
        protected void DrawBelts(GameTime gameTime)
        {
            foreach (Belt belt in beltList)
            {
                _spriteBatch.Begin();
                belt.Draw(gameTime, _spriteBatch);
                _spriteBatch.End();
            }
        }
        protected void DrawBurgerComponents(GameTime gameTime)
        {
            foreach (BurgerComponent bc in listBurgerComponent)
            {
                _spriteBatch.Begin();
                bc.Draw(gameTime, _spriteBatch);
                _spriteBatch.End();
            }
        }
            protected void DrawCustomerOrderBoard(GameTime gameTime,List<CustomerOrder> customerOrderList)
        {

            _spriteBatch.Begin();
            customerOrderBoard.Draw(gameTime, _spriteBatch);
            _spriteBatch.End();
            //Draw all the checkmarks for the orders in the customerOrderBoard
            foreach(CustomerOrder co in customerOrderList)
            {
                foreach (CheckMark ck in co.CustomerOrderCheckMarkList)
                {
                    _spriteBatch.Begin();
                    ck.Draw(gameTime, _spriteBatch);
                    _spriteBatch.End();
                }
            }
        }
        protected void DrawPlayer(GameTime gameTime)
        {
            _spriteBatch.Begin();
            chef.Draw(gameTime, _spriteBatch);
            _spriteBatch.End();
        }
        protected void DrawPattyList(GameTime gameTime)
        {

            foreach (BurgerPatty bp in flames.PattyList)
            {
                _spriteBatch.Begin();
                bp.Draw(gameTime, _spriteBatch);
                _spriteBatch.End();

               


            }
        }
        #endregion

    }
}
