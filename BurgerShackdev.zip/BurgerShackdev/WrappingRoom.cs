﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class WrappingRoom
    {
        private Texture2D wrappingRoomBackgroundTexture;

        private Texture2D colorTopBunTexture;
        private Texture2D colorPattyTexture;
        private Texture2D colorBottomBunTexture;
        private Texture2D coloredburgerLayerTexture;
        private Texture2D redStackableBurger;
        private Texture2D greenStackableBurger;
        private Texture2D blueStackableBurger;

        private BurgerOrder completeBurgerOrder;
        private float fBurgerOrderZoom;
        private const int emptyBurgerPlatterTextureHeight = 32;
        private List<WrappingRoomChute> wrappingRoomChuteList;
        private OrderColor targetChuteColor;
        private bool bDrawWrapper;
        public OrderColor TargetChuteColor
        {
            get { return targetChuteColor; }
            set { targetChuteColor = value; }
        }


        public Texture2D WrappingRoomBackGroundTexture
        {
            get { return wrappingRoomBackgroundTexture; }
            set { wrappingRoomBackgroundTexture = value; }
        }
        public BurgerOrder CompleteBurgerOrder
        {
            get { return completeBurgerOrder; }
            set { completeBurgerOrder = value; }
        }


        //Constructor
        public WrappingRoom(BurgerOrder bo, Vector2 chefPosition, ContentManager content)
        {
            completeBurgerOrder = bo;
            fBurgerOrderZoom = 1f;
            completeBurgerOrder.BurgerOrderPosition = chefPosition;
            wrappingRoomChuteList = new List<WrappingRoomChute>();
            WrappingRoomChute redChute = AddWrappingRoomCHute(new Vector2(100, 300), OrderColor.Red, content);
            WrappingRoomChute greenChute = AddWrappingRoomCHute(new Vector2(300, 300), OrderColor.Green, content);
            WrappingRoomChute blueChute = AddWrappingRoomCHute(new Vector2(600, 300), OrderColor.Blue, content);
            redChute.LoadContent(content);
            greenChute.LoadContent(content);
            blueChute.LoadContent(content);

            wrappingRoomChuteList.Add(redChute);
            wrappingRoomChuteList.Add(greenChute);
            wrappingRoomChuteList.Add(blueChute);
            bDrawWrapper = false;
        }
        public WrappingRoom(Vector2 chefPosition, List<BurgerOrder> burgerOrders, ContentManager Content, OrderColor targetChuteColor)
        {
            this.targetChuteColor = targetChuteColor;
            completeBurgerOrder = new BurgerOrder(chefPosition);
            foreach (BurgerOrder bo in burgerOrders)
            {
                if (bo.BurgerOrderClosed == true)
                {
                    completeBurgerOrder = bo;
                    targetChuteColor = bo.BurgerrOrderColor;
                    break;
                }
            }

            fBurgerOrderZoom = 1f;
            completeBurgerOrder.BurgerOrderPosition = chefPosition;
            wrappingRoomChuteList = new List<WrappingRoomChute>();
            WrappingRoomChute redChute = AddWrappingRoomCHute(new Vector2(100, 200), OrderColor.Red, Content);
            WrappingRoomChute greenChute = AddWrappingRoomCHute(new Vector2(300, 200), OrderColor.Green, Content);
            WrappingRoomChute blueChute = AddWrappingRoomCHute(new Vector2(500, 200), OrderColor.Blue, Content);
            wrappingRoomChuteList.Add(redChute);
            wrappingRoomChuteList.Add(greenChute);
            wrappingRoomChuteList.Add(blueChute);
            bDrawWrapper = false;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            //Draw Background
            spriteBatch.Begin();
            spriteBatch.Draw(wrappingRoomBackgroundTexture, new Vector2(0, 50), Color.White);
            spriteBatch.End();
            //Draw Each of the WrappingRoomChutes in the WrappingRoom Chute List
            foreach (WrappingRoomChute wrappingRoomChute in wrappingRoomChuteList)
            {
                //Draw Chute
                wrappingRoomChute.Draw(gameTime, spriteBatch);
            }
            //Draw each of the ALready wrapped burgers
            foreach (WrappingRoomChute chute in wrappingRoomChuteList)
            {
                int burgercounter = 0;
                foreach (BurgerOrder bo in chute.ChuteBurgerOrders)
                {

                    switch (chute.ChuteColor)
                    {
                        case OrderColor.Red:
                            //draw the red burger on top of the red stack, in the center of the chute. adjust verticle position according to the number of burgers
                            spriteBatch.Begin();
                            spriteBatch.Draw(redStackableBurger, new Vector2(chute.ChuteTargetCollisionBox.X, chute.ChuteTargetCollisionBox.Y - burgercounter * redStackableBurger.Height), Color.White);
                            spriteBatch.End();
                            break;
                        case OrderColor.Green:
                            //draw the green burger on top of the green  stack
                            spriteBatch.Begin();
                            spriteBatch.Draw(greenStackableBurger, new Vector2(chute.ChuteTargetCollisionBox.X, chute.ChuteTargetCollisionBox.Y - burgercounter * redStackableBurger.Height), Color.White);
                            spriteBatch.End();
                            break;
                        case OrderColor.Blue:
                            //draw the blue burger on top of the blue stack
                            spriteBatch.Begin();
                            spriteBatch.Draw(blueStackableBurger, new Vector2(chute.ChuteTargetCollisionBox.X, chute.ChuteTargetCollisionBox.Y - burgercounter * redStackableBurger.Height), Color.White);
                            spriteBatch.End();
                            break;
                    }
                    burgercounter += 1;
                }
            }
            //Draw Burger Order (Chefs)
            foreach (BurgerLayer bl in completeBurgerOrder.BurgerLayerList)
            {
                spriteBatch.Begin();
                //We have a match burgerorder to the customerOrder, so we draw wit the tint of the customerorder which has already been assigned to the burgeroder. 

                switch (completeBurgerOrder.BurgerrOrderColor)
                {
                    case OrderColor.Red:
                    case OrderColor.Green:
                    case OrderColor.Blue:
                        switch (bl.LayerNumber)
                        {
                            case 0://Code to draw the item in the first slot at the first slot location
                                   //Should always be Empty

                                break;
                            case 1:
                                //Should always be bottombun slot 1 
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        //Draw the bottombun in the first slot
                                        bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, completeBurgerOrder.BurgerOrderPosition.Y + emptyBurgerPlatterTextureHeight / 2 - bl.BurgerLayerTexture.Height / 2), fBurgerOrderZoom, completeBurgerOrder.BurgerrOrderColor, colorBottomBunTexture, bDrawWrapper);
                                        break;
                                    default://Throw Exception
                                        break;

                                }
                                break;
                            case 2://slot2.PATTY ONLY
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        // Draw the bottombun in the seocnd slot. This should never occur.
                                        break;
                                    case "patty":
                                        // Draw the patty in the seocnd slot. This should always occur.
                                        bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, (completeBurgerOrder.BurgerOrderPosition.Y + (emptyBurgerPlatterTextureHeight / 2) / 2 - bl.BurgerLayerTexture.Height / 2)), fBurgerOrderZoom, completeBurgerOrder.BurgerrOrderColor, colorPattyTexture, bDrawWrapper);
                                        break;
                                    default://Throw Exception
                                        break;

                                }

                                break;
                            default://No coloe assigned yet as color is assigned when the burger intersects the chute. Draw regulear burger.
                                switch (bl.BurgerLayerType)
                                {

                                    //case "topbun":

                                    //    bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, (completeBurgerOrder.BurgerOrderPosition.Y + (emptyBurgerPlatterTextureHeight / 2) / 2 - bl.BurgerLayerTexture.Height / 2)), fBurgerOrderZoom, completeBurgerOrder.BurgerrOrderColor, colorTopBunTexture);
                                    //    break;
                                    default:
                                        bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, (completeBurgerOrder.BurgerOrderPosition.Y + (emptyBurgerPlatterTextureHeight / 3) / 2 - bl.BurgerLayerTexture.Height / 2 * (bl.LayerNumber))), fBurgerOrderZoom, completeBurgerOrder.BurgerrOrderColor, bl.BurgerLayerTexture, bDrawWrapper);
                                        break;


                                }

                                break;




                        }
                        break;





                    default:
                        switch (bl.LayerNumber)
                        {
                            case 0://Code to draw the item in the first slot at the first slot location
                                   //Should always be Empty

                                break;
                            case 1:
                                //Should always be bottombun slot 1 
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        //Draw the bottombun in the first slot

                                        bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, completeBurgerOrder.BurgerOrderPosition.Y + emptyBurgerPlatterTextureHeight / 2 - bl.BurgerLayerTexture.Height / 2), fBurgerOrderZoom);

                                        break;
                                    default://Throw Exception
                                        break;

                                }
                                break;
                            case 2://slot2.PATTY ONLY
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        // Draw the bottombun in the seocnd slot. This should never occur.
                                        break;
                                    case "patty":
                                        // Draw the patty in the seocnd slot. This should always occur.
                                        bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, (completeBurgerOrder.BurgerOrderPosition.Y + (emptyBurgerPlatterTextureHeight / 2) / 2 - bl.BurgerLayerTexture.Height / 2)), fBurgerOrderZoom);
                                        break;
                                    default://Throw Exception
                                        break;

                                }

                                break;
                            default:
                                bl.Draw(gameTime, spriteBatch, new Vector2(completeBurgerOrder.BurgerOrderPosition.X, (completeBurgerOrder.BurgerOrderPosition.Y + (emptyBurgerPlatterTextureHeight / 3) / 2 - bl.BurgerLayerTexture.Height / 2 * (bl.LayerNumber))), fBurgerOrderZoom);
                                break;


                        }
                        break;

                }

                spriteBatch.End();
            }



        }


        public void LoadContent(ContentManager Content)
        {
            wrappingRoomBackgroundTexture = Content.Load<Texture2D>("BackGround/wrappingRoom");
            colorTopBunTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/color/topbun");
            colorPattyTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/color/burgerPatty");
            colorBottomBunTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/color/bottombun");
            coloredburgerLayerTexture = Content.Load<Texture2D>("burgerComponents/burgerlayers/color/CheeseLayer");
            //Stackable red green blue burgers
            redStackableBurger = Content.Load<Texture2D>("StackableColorBurgers/RedBurger48x48");
            greenStackableBurger = Content.Load<Texture2D>("StackableColorBurgers/GreenBurger48x48");
            blueStackableBurger = Content.Load<Texture2D>("StackableColorBurgers/BlueBurger48x48");
        }
        public void Update(GameTime gameTime, ref Chef chef, ref Game1.GameState gameState)
        {
            foreach (WrappingRoomChute chute in wrappingRoomChuteList)
            {
                //*************************************************************************************
                //Set the burger order color to the color of Chute it intersects with - if match on the customer order board then score success otheriwse lose points
                if (completeBurgerOrder.BurgerOrderCollisionRect.Intersects(chute.ChuteCollisionBox))
                {
                    if (chute.ChuteColor == targetChuteColor)
                    {
                        //HIT
                        completeBurgerOrder.BurgerrOrderColor = chute.ChuteColor;
                        //Now we should draw the burger the color of the wrapper its in
                        bDrawWrapper = true;
                        //Place the burgerOrder in the center of the chute horizontally
                        completeBurgerOrder.BurgerOrderPosition = new Vector2(chute.ChutePosition.X + chute.ChuteTexture.Width - coloredburgerLayerTexture.Width, completeBurgerOrder.BurgerOrderPosition.Y);

                    }
                    //Check if burgerorder intersects the chute's target - successful delivery of order
                    if (chute.ChuteTargetCollisionBox.Intersects(completeBurgerOrder.BurgerOrderCollisionRect) && chute.ChuteColor == targetChuteColor)
                    {
                        chef.Score += 100;
                        chef.ChefPosition = chef.ChefStartPosition;
                        chef.BHasCompleteOrder = false;
                        chef.ChefBurgerLayer = null;
                        chef.ChefCompleteBurgerOrder.BurgerOrderFlaggedForDelete = true;
                        //add the burger to the burgerSlots list for this chute. it  is a list of lists.(to a max3)
                        if (chute.ChuteBurgerOrders.Count < 4)
                        {
                            BurgerOrder chuteBurgerOrder = new BurgerOrder();
                            chuteBurgerOrder = completeBurgerOrder;
                            chute.ChuteBurgerOrders.Add(chuteBurgerOrder);
                            //completeBurgerOrder = null;
                            //Remove CUstomer order!??from board
                        }
                        else
                        {
                            //Chute Has 4 Orders and is full.
                        }
                        gameState = Game1.GameState.GameStarting;

                    }
                }
            }

            //*************************************************************************************
            //If the chef presswed space then move the burgerorder down ie drop it
            if (completeBurgerOrder.BurgerOrderDropInChute == true)
            {
                completeBurgerOrder.BurgerOrderPosition = new Vector2(completeBurgerOrder.BurgerOrderPosition.X, completeBurgerOrder.BurgerOrderPosition.Y + 1 * completeBurgerOrder.FMovementSpeed);
                completeBurgerOrder.BurgerOrderCollisionRect = new Rectangle((int)completeBurgerOrder.BurgerOrderPosition.X, (int)completeBurgerOrder.BurgerOrderPosition.Y + 16, 32, 32);

            }
            else
            {
                completeBurgerOrder.BurgerOrderPosition = new Vector2(chef.ChefPosition.X - chef.ChefWidth / 2, chef.ChefPosition.Y);
            }
        }
        public WrappingRoomChute AddWrappingRoomCHute(Vector2 chutePosition, OrderColor chuteColor, ContentManager content)
        {

            WrappingRoomChute chute = new WrappingRoomChute(chutePosition, chuteColor);
            chute.LoadContent(content);
            return chute;

        }
    }
}