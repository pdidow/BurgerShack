﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BurgerShack
{
    public class CustomerOrder
    {
        private List<BurgerLayer> customerBurgerOrderLayerList;
        private BottomBun customerBurgerOrderbottomBun;
        private BurgerPatty burgerOrderBurgerPatty;
        private bool customerOrderFlaggedForDelete;
        private List<CheckMark> customerOrderCheckMarkList;
        private int customerOrderNumber;
        private Random randomSeed;
        private OrderColor customerOrderColor;
        private bool bMatchedToBurgerOrder;

        public bool BMatchedToBurgerOrder
        {
            get { return bMatchedToBurgerOrder; }
            set { bMatchedToBurgerOrder = value; }
        }

        public OrderColor CustomerOrderColor
        {
            get { return customerOrderColor; }
            set { customerOrderColor = value; }
        }
        public int CustomerOrderNumber
        {
            get { return customerOrderNumber; }
            set { customerOrderNumber = value; }
        }


        public List<CheckMark> CustomerOrderCheckMarkList
        {
            get { return customerOrderCheckMarkList; }
            set { customerOrderCheckMarkList = value;            }

        }

        //A customer order is comprised of the layerList and the bottomBun and burger patty meat like a burgerorder. 

                //Constructor
        public CustomerOrder(int lastOrderNumber)
        {
           
            customerBurgerOrderLayerList = new List<BurgerLayer>();//initialize empty burgerOrderLayerList to build our burger

            customerOrderFlaggedForDelete = false;
            customerBurgerOrderLayerList.Add(new BurgerLayer("bottombun"));
            customerBurgerOrderLayerList.Add(new BurgerLayer("patty"));
            customerOrderCheckMarkList = new List<CheckMark>();
            customerOrderNumber = lastOrderNumber + 1;
            customerOrderColor = GetRandomColor();
            bMatchedToBurgerOrder = false;
          
        //AddCheckMarkToCustomerOrderCheckMarkList()
        }
        public BurgerPatty BurgerOrderBurgerPatty
        {
            get { return burgerOrderBurgerPatty; }
            set { burgerOrderBurgerPatty = value; }
        }

        public List<BurgerLayer> BurgerLayerList
        {
            get { return customerBurgerOrderLayerList; }
            set { customerBurgerOrderLayerList = value; }
        }
        public BottomBun BottomBun
        {
            get { return customerBurgerOrderbottomBun; }
            set { customerBurgerOrderbottomBun = value; }

        }
        public bool CustomerOrderFlaggedForDelete
        {
            get { return customerOrderFlaggedForDelete; }
            set { customerOrderFlaggedForDelete = value; }
        }
        public bool AddCheckMarkToCustomerOrderCheckMarkList(string type, int customerOrdernumber,ContentManager Content)
        {
            bool breturn = false;
            Vector2 checkMarkPosition = new Vector2();
           
            switch (type)
            {
                case "tomato":
                     checkMarkPosition = new Vector2(266, 420 + customerOrdernumber * 8);
                    break;
                    
                case "lettuce":
                    checkMarkPosition = new Vector2(395, 420 + customerOrdernumber * 8);
                    break;
                case "onion":
                    checkMarkPosition = new Vector2(328, 420 + customerOrdernumber * 8);
                    break;
                case "cheese":
                    checkMarkPosition = new Vector2(462, 420 + customerOrdernumber * 8);
                    break;

            }

            CheckMark chk = new CheckMark(checkMarkPosition, type);
            chk.LoadContent(Content);
            customerOrderCheckMarkList.Add(chk);
            return breturn;
        }
        public CustomerOrder GenerateCustomerOrder(List<CustomerOrder> customerOrders, BurgerOrder burgerOrder)
        {
            //Generate a random order, based on levelOfDifficulty
            // Level 1-10 -  1 or 2 condiments per order
            // Level 11-20  1-3 condiments per order. THis is for example only, research further in pressurecooker game design
            int lastOrderNumber = customerOrders.Count() + 1;
            CustomerOrder order = new CustomerOrder(lastOrderNumber);
            //July 8th 2022 edit on line below..  pleases test!
            order.BurgerLayerList.Add(new BurgerLayer(GetRandomCondiment()));
            //Then check if we already have that item, if not add to customerorder. Otherwise choose again.

            return order;
        }
        public string GetRandomCondiment()
        {

            List<string> condimentlist = new List<string> { "cheese", "onion", "lettuce", "tomato" };
            randomSeed = new Random();
            int index = randomSeed.Next(condimentlist.Count);
            return condimentlist[index];
        }
        public OrderColor GetRandomColor()
        {
            //OrderColor returnColor = new OrderColor();
            //Random rand = new Random()

            Array values = Enum.GetValues(typeof(OrderColor));
            Random random = new Random();
            OrderColor randomOrderColor = (OrderColor)values.GetValue(random.Next(values.Length));
            return randomOrderColor;
        }

    }
}
