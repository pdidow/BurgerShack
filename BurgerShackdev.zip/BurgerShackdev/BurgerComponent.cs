﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class BurgerComponent
    {
        private Vector2 burgerComponentPosition;
        private string burgerComponentType;
        private Texture2D onionComponentTexture;
        private Texture2D cheeseComponentTexture;
        private Texture2D lettuceComponentTexture;
        private Texture2D tomatoComponentTexture;
        private Texture2D topbunComponentTexture;
        private Rectangle burgerComponentCollisionBox;
        private int burgerComponentWidth;
        private int burgerComponentHeight;
        private bool bDeleteFlag;
        private float fBurgerZoom;
        public string BurgerComponentType
        {
            get { return burgerComponentType; }
            set { burgerComponentType = value; }
        }
        public Vector2 BurgerComponentPosition
        {
            get { return burgerComponentPosition; }
            set { burgerComponentPosition = value; }
        }
        public Rectangle BurgerComponentCollisionBox
        {
            get { return burgerComponentCollisionBox; }
            set { burgerComponentCollisionBox = value; }
        }
        public int BurgerComponentWidth
        {
            get { return burgerComponentWidth; }
            set { burgerComponentWidth = value; }
        }
        public int BurgerComponentHeight
        {
            get { return burgerComponentHeight; }
            set { burgerComponentHeight = value; }
        }
        public bool BDeleteFlag
        {
            get { return bDeleteFlag; }
            set { bDeleteFlag = value; }
        }
        //Constructor
        public BurgerComponent(string type)
        {
            burgerComponentType = type;
            //start position depends on type
            float screenWidth = 640;
            switch (burgerComponentType)
            {
                case "onion":
                    burgerComponentPosition = new Vector2(screenWidth - 32, 185);
                    
                    break;
                case "cheese":
                    burgerComponentPosition = new Vector2(screenWidth - 32, 230);
                    break;
                case "lettuce":
                    burgerComponentPosition = new Vector2(screenWidth - 32, 280);
                    break;
                case "tomato":
                    burgerComponentPosition = new Vector2(screenWidth - 32, 330);
                    break;
                case "topbun":
                    burgerComponentPosition = new Vector2(screenWidth - 32, 385);
                    break;
            }
            bDeleteFlag = false;
            fBurgerZoom = 1.25f;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            //Draw the Burger Component
            switch (burgerComponentType)
                {
                case "onion":
                    //draw onion component
                    spriteBatch.Draw(onionComponentTexture, burgerComponentPosition, null, Color.White, 0f,
                    Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
                    break;
                case "cheese":
                    //draw cheese component
                    spriteBatch.Draw(cheeseComponentTexture, burgerComponentPosition, null, Color.White, 0f,
                    Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
                    break;
                case "lettuce":
                    //draw lettuce component
                    spriteBatch.Draw(lettuceComponentTexture, burgerComponentPosition, null, Color.White, 0f,
                    Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
                    break; //draw 
                case "tomato":
                    spriteBatch.Draw(tomatoComponentTexture, burgerComponentPosition, null, Color.White, 0f,
                    Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
                    break;
                case "topbun":
                    //draw topbun component
                    spriteBatch.Draw(topbunComponentTexture, burgerComponentPosition, null, Color.White, 0f,
                    Vector2.Zero, fBurgerZoom, SpriteEffects.None, 0f);
                    break;
                    
            }

        }
        public void LoadContent(ContentManager Content)
        {
            onionComponentTexture = Content.Load<Texture2D>("burgerComponents/onion_brown");
            cheeseComponentTexture = Content.Load<Texture2D>("burgerComponents/Cheese");
            lettuceComponentTexture = Content.Load<Texture2D>("burgerComponents/lettuce");
            tomatoComponentTexture = Content.Load<Texture2D>("burgerComponents/tomato");
            topbunComponentTexture = Content.Load<Texture2D>("burgerComponents/topbun");

        }

            public void Update(GameTime gameTime, Vector2 boundry)
        {
            //Move the burger component. Do Collision Detection for left converyer wall.
            //Update the position
            burgerComponentPosition = new Vector2(burgerComponentPosition.X - 1, burgerComponentPosition.Y);            
            burgerComponentCollisionBox = new Rectangle((int)burgerComponentPosition.X-(int)burgerComponentWidth/2,(int) burgerComponentPosition.Y-(int)burgerComponentHeight/2, burgerComponentWidth, burgerComponentHeight);
            //Check ConveyorWall Collision
            CheckWallCollision();

        }
        public void CheckWallCollision()
        {

        }

    }
}
