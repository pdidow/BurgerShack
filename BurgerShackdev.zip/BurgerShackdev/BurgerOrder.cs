﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static BurgerShack.Game1;

namespace BurgerShack
{
    public class BurgerOrder 
    {
        private List<BurgerLayer> burgerOrderLayerList;
        private BottomBun burgerOrderbottomBun;
        private BurgerPatty burgerOrderBurgerPatty;
        private Texture2D emptyBurgerPlatterTexture;
        private Vector2 burgerOrderPosition;
        private Rectangle burgerOrderCollisionRect;
        private float fBurgerOrderZoom;
        private float fChefBurgerOrderZoom;
        private bool emptyPlatter;
        private float fPlatterTimer;
        private Vector2 startPosition;
        private float fmovementSpeed;
        private bool burgerOrderClosed;
        private bool burgerOrderFlaggedForDelete;
        private bool burgerOrderDropInChute;
        private OrderColor burgerOrderColor;

        public OrderColor BurgerrOrderColor
        {
            get { return burgerOrderColor; }
            set { burgerOrderColor = value; }
        }
        //A burger order is comprised of the layerList and the bottomBun and burger patty meat
        //Constructor(s)
        public BurgerOrder()
        {
            burgerOrderPosition = new Vector2(0, 0);
            emptyPlatter = true;//Start with an empty platter.
            fBurgerOrderZoom = 1f;
            fChefBurgerOrderZoom = .25f;
            burgerOrderLayerList = new List<BurgerLayer>();//initialize empty burgerOrderLayerList to build our burger            

            startPosition = burgerOrderPosition;
            fmovementSpeed = 1f;
            burgerOrderClosed = false;
            burgerOrderFlaggedForDelete = false;
            burgerOrderDropInChute = false;
        }
        public BurgerOrder(Vector2 position)
        {
            //Start with an empty Platter
            burgerOrderPosition = position;
            emptyPlatter = true;//Start with an empty platter.
            fBurgerOrderZoom = 1f;
            fChefBurgerOrderZoom = .25f;
            burgerOrderLayerList = new List<BurgerLayer>();//initialize empty burgerOrderLayerList to build our burger            

            startPosition = position;
            fmovementSpeed = 1f;
            burgerOrderClosed = false;
            burgerOrderFlaggedForDelete = false;
            burgerOrderDropInChute = false;
        }
        public BurgerPatty BurgerOrderBurgerPatty
        {
            get { return burgerOrderBurgerPatty; }
            set { burgerOrderBurgerPatty = value; }
        }
        public bool BurgerOrderClosed
        {
            get { return burgerOrderClosed; }
            set { burgerOrderClosed = value; }
        }


        public List<BurgerLayer> BurgerLayerList
        {
            get { return burgerOrderLayerList; }
            set { burgerOrderLayerList = value; }
        }
        public BottomBun BottomBun
        {
            get { return burgerOrderbottomBun; }
            set { burgerOrderbottomBun = value; }

        }
        public bool EmptyPlatter
        {
            get { return emptyPlatter; }
            set { emptyPlatter = value; }
        }
        public Rectangle BurgerOrderCollisionRect
        {
            get { return burgerOrderCollisionRect; }
            set { burgerOrderCollisionRect = value; }
        }
        public float FMovementSpeed
        {
            get { return fmovementSpeed; }
            set { fmovementSpeed = value; }
        }
        public bool BurgerOrderFlaggedForDelete
        {
            get { return burgerOrderFlaggedForDelete; }
            set { burgerOrderFlaggedForDelete = value; }
        }

        public bool BurgerOrderDropInChute
        {
            get { return burgerOrderDropInChute; }
            set { burgerOrderDropInChute = value; }
        }
        public Vector2 BurgerOrderPosition
        {
            get { return burgerOrderPosition; }
            set { burgerOrderPosition = value; }
        }
        

        public void LoadContent(ContentManager Content)
        {

            emptyBurgerPlatterTexture = Content.Load<Texture2D>("burgerComponents/emptyPlatter");
            burgerOrderCollisionRect = new Rectangle((int)burgerOrderPosition.X, (int)burgerOrderPosition.Y + emptyBurgerPlatterTexture.Height / 2, emptyBurgerPlatterTexture.Width, emptyBurgerPlatterTexture.Height / 2);


        }
        public bool Update(GameTime gameTime, Rectangle chefCollisionRect, BurgerLayer chefBurgerLayer, Rectangle conveyorRect,List<CustomerOrder> customerOrders)
        {
            bool bRemoveChefBurgerLayer = false;
           

            if (burgerOrderDropInChute == false)
            {
                //Move burger components/platter down the conveyer;
                burgerOrderPosition = new Vector2(burgerOrderPosition.X, burgerOrderPosition.Y + 1 * fmovementSpeed);
                


                burgerOrderCollisionRect = new Rectangle((int)burgerOrderPosition.X, (int)burgerOrderPosition.Y + emptyBurgerPlatterTexture.Height / 2, emptyBurgerPlatterTexture.Width, emptyBurgerPlatterTexture.Height / 2);
                if (burgerOrderCollisionRect.Intersects(chefCollisionRect))
                {
                   
                    if (chefBurgerLayer != null && burgerOrderClosed == false)//ensure chef is carrying an item and the order has not been closed already
                    {


                        //ensure the burgerorder has a bottombun and a patty before we can add to the burger.
                        var item = BurgerLayerList.FindAll(x => (x.BurgerLayerType == "bottombun") || (x.BurgerLayerType == "patty"));

                        if (item.Count >= 2)
                        {
                            //set the layer number to 0 as default.
                            chefBurgerLayer.LayerNumber = burgerOrderLayerList.Count + 1;
                            burgerOrderLayerList.Add(chefBurgerLayer);
                            bRemoveChefBurgerLayer = true;
                            //Close the BurgerORder if the topBun is placed.
                            if (chefBurgerLayer.BurgerLayerType == "topbun")
                            {
                                burgerOrderClosed = true;
                                //Check for a Match as burger is now closed
                                foreach (CustomerOrder customerOrder in customerOrders)
                                {
                                    //Check for each field to match 
                                    //var sql=customerlayers from layerType in customerOrder join burgerLayerType on 
                                    if (MatchBurger(customerOrder.BurgerLayerList,burgerOrderLayerList)) //The layerlists of the burgerOrder and the CUstomerOrder need to match, regardless of order. 
                                    {
                                        //Match! Set the color of the burger order to that of the customerOrder. This color is passed to the wrapping room for the target wrapping room color.
                                        burgerOrderColor = customerOrder.CustomerOrderColor;
                                        //flash the customer oreder now
                                        customerOrder.BMatchedToBurgerOrder = true;
                                    }
                                   

                                }

                            }
                        }
                    }

                }
                if (burgerOrderPosition.Y > conveyorRect.Bottom)//should be the bottom of the conveyor
                {
                    burgerOrderPosition = startPosition;
                }
            }
            else if (burgerOrderDropInChute==true)
            {
                foreach (BurgerLayer bl in BurgerLayerList)
                {
                    bl.BurgerLayerPosition = new Vector2(bl.BurgerLayerPosition.X, bl.BurgerLayerPosition.Y + 1 * fmovementSpeed);
                 


                }
                burgerOrderPosition = new Vector2(burgerOrderPosition.X, burgerOrderPosition.Y + 1 * fmovementSpeed);
            }


            return bRemoveChefBurgerLayer;
        }
        public static bool MatchBurger(List<BurgerLayer> customerOrderBurgerLayers,List<BurgerLayer> burgerOrderBurgerLayers)
        {
            List<string> customerOrderLayers=new List<string>();
            List<string> burgerOrderLayers = new List<string>();
           
            foreach (BurgerLayer bl in customerOrderBurgerLayers)
            {
                customerOrderLayers.Add(bl.BurgerLayerType.ToString());
            }
            foreach (BurgerLayer bl in burgerOrderBurgerLayers)
            {
                burgerOrderLayers.Add(bl.BurgerLayerType.ToString());
            }
            bool bBurgerMatch = customerOrderLayers.OrderBy(x => x).SequenceEqual(burgerOrderLayers.OrderBy(x => x));
           
            return bBurgerMatch;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            //Draw the empty platter for an unforfilled burgerOrder
            if (emptyPlatter == true)
            {
                spriteBatch.Draw(emptyBurgerPlatterTexture, burgerOrderPosition, null, Color.White, 0f,
                Vector2.Zero, fBurgerOrderZoom, SpriteEffects.None, 0f);
            }
            //Draw the BurgerOrder as Collected by chef
            //via burgerLayerList.item.
            //
            //items are added to this list when chef is carrying chef.ChefBurgerLayer and intersects the collisionRect [ burgerOrderCollisionRect]of the burgerOrder
            //in Update
            if (burgerOrderLayerList != null)
            {
                int numberofLayers = burgerOrderLayerList.Count;


                foreach (BurgerLayer bl in burgerOrderLayerList)
                {

                    //The correct way to do this is to switch(layerTYpe) for each layer in in BurgerOrder


                    switch (bl.LayerNumber)
                    {
                        case 0://Code to draw the item in the first slot at the first slot location
                               //Should always be Empty

                            break;
                        case 1:
                            //Should always be bottombun slot 1 
                            switch (bl.BurgerLayerType)
                            {
                                case "bottombun":
                                    //Draw the bottombun in the first slot
                                    bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, burgerOrderPosition.Y + emptyBurgerPlatterTexture.Height / 2 - bl.BurgerLayerTexture.Height / 2), fBurgerOrderZoom);

                                    break;
                                default://Throw Exception
                                    break;

                            }
                            break;
                        case 2://slot2.PATTY ONLY
                            switch (bl.BurgerLayerType)
                            {
                                case "bottombun":
                                    // Draw the bottombun in the seocnd slot. This should never occur.
                                    break;
                                case "patty":
                                    // Draw the patty in the seocnd slot. This should always occur.
                                    bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, (burgerOrderPosition.Y + (emptyBurgerPlatterTexture.Height / 2) / 2 - bl.BurgerLayerTexture.Height / 2)), fBurgerOrderZoom);
                                    break;
                                default://Throw Exception
                                    break;

                            }

                            break;
                        default:
                            bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, (burgerOrderPosition.Y + (emptyBurgerPlatterTexture.Height / 3) / 2 - bl.BurgerLayerTexture.Height / 2 * (bl.LayerNumber))), fBurgerOrderZoom);
                            break;


                    }




                }
            }

        }
        //Overloaded the Draw method to accept the chef position. This is for drawing the completed burger on the chef like he is carrying it
        public void DrawChefWithBurger(GameTime gameTime, SpriteBatch spriteBatch, ref Chef chef,GameState gameState)
        {

            if (gameState == GameState.GameStarting)
            {
                switch (chef.ChefState)
                {
                    case Chef.chefState.walkRight:
                        burgerOrderPosition = new Vector2(chef.ChefPosition.X, chef.ChefPosition.Y - chef.ChefHeight / 2);
                        break;
                    case Chef.chefState.walkLeft:
                        burgerOrderPosition = new Vector2(chef.ChefPosition.X - emptyBurgerPlatterTexture.Width, chef.ChefPosition.Y - chef.ChefHeight / 2);
                        break;
                    case Chef.chefState.walkUp:
                        burgerOrderPosition = new Vector2(chef.ChefPosition.X - emptyBurgerPlatterTexture.Width / 2, chef.ChefPosition.Y - chef.ChefHeight);
                        break;
                    case Chef.chefState.walkDown:
                        burgerOrderPosition = new Vector2(chef.ChefPosition.X - emptyBurgerPlatterTexture.Width / 2, chef.ChefPosition.Y + chef.ChefHeight);
                        break;
                }
               
              

                if (burgerOrderLayerList != null)
            {
                int numberofLayers = burgerOrderLayerList.Count;


                    foreach (BurgerLayer bl in burgerOrderLayerList)
                    {

                        //The correct way to do this is to switch(layerTYpe) for each layer in in BurgerOrder


                        switch (bl.LayerNumber)
                        {
                            case 0://Code to draw the item in the first slot at the first slot location
                                   //Should always be Empty

                                break;
                            case 1:
                                //Should always be bottombun slot 1 
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        //Draw the bottombun in the first slot
                                        bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, burgerOrderPosition.Y + emptyBurgerPlatterTexture.Height / 2 - bl.BurgerLayerTexture.Height / 2), fBurgerOrderZoom);

                                        break;
                                    default://Throw Exception
                                        break;

                                }
                                break;
                            case 2://slot2.PATTY ONLY
                                switch (bl.BurgerLayerType)
                                {
                                    case "bottombun":
                                        // Draw the bottombun in the seocnd slot. This should never occur.
                                        break;
                                    case "patty":
                                        // Draw the patty in the seocnd slot. This should always occur.
                                        bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, (burgerOrderPosition.Y + (emptyBurgerPlatterTexture.Height / 2) / 2 - bl.BurgerLayerTexture.Height / 2)), fBurgerOrderZoom);
                                        break;
                                    default://Throw Exception
                                        break;

                                }

                                break;
                            default:
                                bl.Draw(gameTime, spriteBatch, new Vector2(burgerOrderPosition.X, (burgerOrderPosition.Y + (emptyBurgerPlatterTexture.Height / 3) / 2 - bl.BurgerLayerTexture.Height / 2 * (bl.LayerNumber))), fBurgerOrderZoom);
                                break;







                        }
                    }
                }
           
            } 

        }

        
    }
    }

