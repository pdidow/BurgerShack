﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using MonoGame.Extended.BitmapFonts;
using static BurgerShack.Game1;

namespace BurgerShack
{
    public class Chef
    {
        private Vector2 chefPosition;
        private Rectangle chefCollisionRect;
        private SpriteAnimation chefSpriteAnimation;//Contains our animation sequences
        private chefState _chefState;
        private KeyboardState pastKey;
        private float chefWidth;
        private float chefHeight;
        const int CHEFDIMENSION = 32;
        private BurgerLayer chefBurgerLayer;
        private int scoreRating;
        private int score;
        private SpriteFont font;
        private float fLayerZoom;
        private float fmovementSpeed;
        private bool bHasCompleteOrder;
        private BurgerOrder chefCompleteBurgerOrder;
        private Vector2 chefStartPosition;
        public Vector2 ChefStartPosition
        {
            get { return chefStartPosition; }
            set { chefStartPosition = value; }
        }
        public enum chefState
        {
            walkRight, walkLeft, walkUp, walkDown,Idle
        };
        //Expose chefState as Public property
        public chefState ChefState
        {
            get { return _chefState; }
            set { _chefState = value; }
        }
        public BurgerOrder ChefCompleteBurgerOrder
        {
            get { return chefCompleteBurgerOrder; }
            set { chefCompleteBurgerOrder = value; }
        }

        //Constructor
        public Chef(Vector2 startPosition)
        {
            //Put chef in home place
            chefPosition = new Vector2(startPosition.X, startPosition.Y);
            //Set Ratingscore to 50
            scoreRating = 50;
            //set score to zero
            score = 0;
            fLayerZoom = 0.5f;
            fmovementSpeed = 2f;
            bHasCompleteOrder = false;
            chefCompleteBurgerOrder = null;
            chefStartPosition = startPosition;
        }
        public Rectangle ChefCollisionRect
        {
            get { return chefCollisionRect; }
            set { chefCollisionRect = value; }
        }
        public float ChefWidth
        {
            get { return chefWidth; }
            set { chefWidth = value; }
        }
        public float ChefHeight
        {
            get { return chefHeight; }
            set { chefHeight = value; }
        }

        public BurgerLayer ChefBurgerLayer
        {
            get { return chefBurgerLayer; }
            set { chefBurgerLayer = value; }
        }
        public Vector2 ChefPosition
        {
            get { return chefPosition; }
            set { chefPosition = value; }
        }
        public int ScoreRating
        {
            get { return scoreRating; }
            set { scoreRating = value; }
        }
        public int Score
        {
            get { return score; }
            set { score = value; }
        }
        public float FMovementSpeed
        {
            get { return fmovementSpeed; }
            set { fmovementSpeed = value; }
        }
        public bool BHasCompleteOrder
        {
            get { return bHasCompleteOrder; }
            set { bHasCompleteOrder = value; }
        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            chefSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Chef/chefSpriteSheet_411_360"), 8, 5); //#frames, # animtions *new chef graphics
            chefSpriteAnimation.FramesPerSecond = 16;
            
            ani.IsLooping = true;
            chefSpriteAnimation.AddAnimation("Up", 4, 8, ani.Copy());
            chefSpriteAnimation.AddAnimation("Left", 2, 8, ani.Copy());
            chefSpriteAnimation.AddAnimation("Right", 3, 8, ani.Copy());
            chefSpriteAnimation.AddAnimation("Down",1,8, ani.Copy());
            chefSpriteAnimation.AddAnimation("Idle", 5, 8, ani.Copy());

            chefSpriteAnimation.Animation = "Idle";
            chefSpriteAnimation.Position = chefPosition;
            chefHeight = CHEFDIMENSION;
            chefWidth = CHEFDIMENSION;
            font = Content.Load<SpriteFont>("fonts/HAMMRF");
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (chefSpriteAnimation.Animation != null)
            {
                chefSpriteAnimation.Draw(spriteBatch,1f);
            }

            

            //Draw scoreRating & score

            spriteBatch.DrawString(font, scoreRating.ToString(), new Vector2(50, 100), Color.White);
            spriteBatch.DrawString(font, score.ToString(), new Vector2(450, 100), Color.White);

        }
        public void DrawBurgerLayer(GameTime gameTime,SpriteBatch spritebatch)
        {


         
            int spacer = 20;
            switch (_chefState)
            {
                case chefState.walkRight:
                    chefBurgerLayer.BurgerLayerPosition = new Vector2(chefPosition.X+spacer/2, chefPosition.Y - chefHeight/5);
                    break;
                case chefState.walkLeft:
                    chefBurgerLayer.BurgerLayerPosition = new Vector2(chefPosition.X -spacer*2, chefPosition.Y -chefHeight/5);
                    break;
                case chefState.walkUp:
                    chefBurgerLayer.BurgerLayerPosition = new Vector2(chefPosition.X - spacer / 2, chefPosition.Y - chefHeight/5);
                    break;
                case chefState.walkDown:
                    chefBurgerLayer.BurgerLayerPosition = new Vector2(chefPosition.X - spacer / 2, chefPosition.Y + chefHeight/5);
                    break;
                case chefState.Idle:
                    chefBurgerLayer.BurgerLayerPosition = new Vector2(chefPosition.X - spacer / 2, chefPosition.Y + chefHeight / 5);
                    break;


            }
            spritebatch.Draw(chefBurgerLayer.BurgerLayerTexture, chefBurgerLayer.BurgerLayerPosition, null, Color.White, 0f, Vector2.Zero, fLayerZoom, SpriteEffects.None,0f);
           

        }
        public void DrawBurgerLayer(GameTime gameTime, SpriteBatch spritebatch,bool brejected)
        {

            
           // chefBurgerLayer.BurgerLayerPosition = new Vector2(ChefBurgerLayer.BurgerLayerPosition.X + chefBurgerLayer.LayerMovermentSpeed, chefBurgerLayer.BurgerLayerPosition.Y);
            spritebatch.Draw(chefBurgerLayer.BurgerLayerTexture, chefBurgerLayer.BurgerLayerPosition, null, Color.White, 0f, Vector2.Zero, fLayerZoom, SpriteEffects.None, 1f);


        }
        public void RemoveBurgerLayer()
        {
            if (chefBurgerLayer!=null)
            {
                chefBurgerLayer = null;
            }
        }
        public void Update(GameTime gameTime,Vector2 boundry,List<Chute> chuteList,ref GameState gameState,List<BurgerOrder> burgerOrders)
        {
            //Set to idle for the case of no input
            chefSpriteAnimation.Animation = "Idle";
            _chefState = chefState.Idle;

           
            //Check for input
            if (Keyboard.GetState().IsKeyDown(Keys.S) && pastKey.IsKeyUp(Keys.S) && chefPosition.Y <= boundry.Y)
            {
                chefSpriteAnimation.Animation = "Down";
                _chefState = chefState.walkDown;
                chefPosition = new Vector2(chefPosition.X, chefPosition.Y + 8);

            }

            if (Keyboard.GetState().IsKeyDown(Keys.W) && pastKey.IsKeyUp(Keys.W) && chefPosition.Y >= 64)
            {
                chefSpriteAnimation.Animation = "Up";
                _chefState = chefState.walkUp;
                chefPosition = new Vector2(chefPosition.X, chefPosition.Y - 8);

            }

            if (Keyboard.GetState().IsKeyDown(Keys.A) && pastKey.IsKeyUp(Keys.A) && chefPosition.X >= 48)
            {
                chefSpriteAnimation.Animation = "Left";
                _chefState = chefState.walkLeft;
                chefPosition = new Vector2(chefPosition.X - 8, chefPosition.Y);

            }

            if (Keyboard.GetState().IsKeyDown(Keys.D) && pastKey.IsKeyUp(Keys.D) && chefPosition.X <= boundry.X)
            {
                chefSpriteAnimation.Animation = "Right";
                _chefState = chefState.walkRight;
                chefPosition = new Vector2(chefPosition.X + 8, chefPosition.Y);

            }
            switch (gameState)
            {
                case GameState.GameStarting:
                    if (Keyboard.GetState().IsKeyDown(Keys.Space) && pastKey.IsKeyUp(Keys.Space) && _chefState == chefState.walkRight && chefBurgerLayer != null)
                    {
                        chefBurgerLayer.BRejected = true;


                    }
                    if (chefBurgerLayer != null && chefBurgerLayer.BRejected == true)
                    {
                        ThrowLayer(chefBurgerLayer, gameTime);
                    }

                    if (chefBurgerLayer != null)
                    {
                        chefBurgerLayer.Update(gameTime, chefPosition, chuteList);
                    }
                    if (chefBurgerLayer != null && chefBurgerLayer.BRecovered == true)
                    {
                        score += 100;//or whatever. then remove component
                        chefBurgerLayer = null;
                    }
                    break;
                case GameState.WrappingRoom:
                    foreach (BurgerOrder bo in burgerOrders)
                    {
                        if (bo.BurgerOrderClosed==true)
                        {
                            if (Keyboard.GetState().IsKeyDown(Keys.Space) && pastKey.IsKeyUp(Keys.Space))
                            {
                                //Drop BUrger!

                                bo.BurgerOrderDropInChute = true;
                            }

                        }
                    }
                   
                    break;
            }
            chefCollisionRect = new Rectangle((int)chefPosition.X-(int)chefWidth/2, (int)chefPosition.Y-(int)chefHeight/2, (int)chefWidth, (int)chefHeight);
            chefSpriteAnimation.Position = chefPosition;
            chefSpriteAnimation.Update(gameTime);
          
        }
       
        public void ThrowLayer(BurgerLayer chefBurgerLayer,GameTime gameTime)
         {
            //Reject the cheflAyer and throw it back
            
            chefBurgerLayer.BurgerLayerPosition = new Vector2(chefBurgerLayer.BurgerLayerPosition.X + chefBurgerLayer.LayerMovermentSpeed, chefBurgerLayer.BurgerLayerPosition.Y);
            
        }

    }
    
}
