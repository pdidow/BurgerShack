﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class BottomBunPooper

    {
        private SpriteAnimation bottomBunPooperSpriteAnimation;//Contains our pooper animation sequences
        private Vector2 bottomBunPosition;        
        private List<BottomBun> bottomBunList;
        private BottomBun bottombun;
        private int bottomBunPooperWidth;
        private int bottomBunPooperHeight;

        public List<BottomBun> BottomBunList
        {
            get { return bottomBunList; }
            set { bottomBunList = value; }
        }
        public BottomBunPooper()
        {
            bottomBunPosition = new Vector2(417,90);
            bottomBunPooperWidth = 41;
            bottomBunPooperHeight = 37;
            bottomBunList = new List<BottomBun>();

        }
        public int BottomBunPooperWidth
        {
            get { return bottomBunPooperWidth; }
            set { bottomBunPooperWidth = value; }
        }
        public int BottomBunPooperHeight
        {
            get { return bottomBunPooperHeight; }
            set { bottomBunPooperHeight = value; }
        }
        public Vector2 BottomBunPooperPosition
        {
            get { return bottomBunPosition; }
            set { bottomBunPosition = value; }
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (bottomBunPooperSpriteAnimation.Animation != null)
            {
                bottomBunPooperSpriteAnimation.Draw(spriteBatch,1f);
            }
        }
       
        public void Update(GameTime gameTime)
        {
            bottomBunPooperSpriteAnimation.Update(gameTime);
            foreach (BottomBun bb in bottomBunList)
            {
                if (bb.BFlaggedDelete==true)
                {
                    bottomBunList.Remove(bb);
                }
            }


        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            bottomBunPooperSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("burgerComponents/burgerlayers/BottomBunPooperSpriteAnimationnew"), 5,1); //#frames, # animtions
            bottomBunPooperSpriteAnimation.FramesPerSecond = 5;

            ani.IsLooping = true;
            bottomBunPooperSpriteAnimation.AddAnimation("Poop", 1, 5, ani.Copy());

            bottomBunPooperSpriteAnimation.Animation = "Poop";
            bottomBunPooperSpriteAnimation.Position = bottomBunPosition;
            
        }
        public void AddBottomBun(ContentManager Content,Vector2 position)
        {
            //On timer, generate new bottom bun.
            bottombun = new BottomBun((position));
            bottombun.LoadContent(Content);
            bottomBunList.Add(bottombun);
        }
    }
}
