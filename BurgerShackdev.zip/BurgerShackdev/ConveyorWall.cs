﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class ConveyorWall
    {
        private Vector2 wallPosition;
        private Rectangle wallCollisionRect;
        private Texture2D wallTexture;
        private List<BurgerOrder> listBurgerOrders;

        public Vector2 WallPosition
        {
            get { return wallPosition; }
            set { wallPosition = value; }
        }
        public Rectangle WallCollisionRect
        {
            get { return wallCollisionRect; }
            set { wallCollisionRect = value; }
        }
        public Texture2D WallTexture
        {
            get { return wallTexture; }
            set { wallTexture = value; }
        }
        public List<BurgerOrder> ListBurgerOrders
        {
            get { return listBurgerOrders; }
            set { listBurgerOrders = value; }
        }


        //Constructor
        public ConveyorWall()
        {
            wallPosition = new Vector2(150, 170);
            listBurgerOrders = new List<BurgerOrder>();

        }
        public void LoadContent(ContentManager Content)
        {
            wallTexture = Content.Load<Texture2D>("ConveyorWall/conveyor");
            wallCollisionRect = new Rectangle((int)wallPosition.X, (int)wallPosition.Y,wallTexture.Width, wallTexture.Height);
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(wallTexture, wallPosition, Color.White);
            spriteBatch.End();
        }
    }
}
