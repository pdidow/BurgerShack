﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class Cog
    {
        private string cogDirection_right_left;
        private Vector2 cogPosition;        
        private float cogWidth;
        private float cogHeight;
        private float fCogZoom;
        private SpriteAnimation cogTurningAnimation;


        public string CogDirection
        {
            get { return cogDirection_right_left; }
            set { cogDirection_right_left = value; }
        }

        public Vector2 CogPosition
        {
            get { return cogPosition; }
            set { cogPosition = value; }
        }
       
        public float CogWidth
        {
            get { return cogWidth; }
            set { cogWidth = value; }
        }
        public float CogHeight
        {
            get { return cogHeight; }
            set { cogHeight = value; }
        }


        public Cog(string cogDirection_right_left, Vector2 cogPosition)
        {
            this.cogDirection_right_left = cogDirection_right_left;
            this.cogPosition = cogPosition;
            this.cogWidth = 24;
            this.cogHeight = 12;
           
        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            cogTurningAnimation = new SpriteAnimation(Content.Load<Texture2D>("Cog/cogSpriteSheet"), 3, 1); //#frames, # animtions
            cogTurningAnimation.FramesPerSecond = 3;
            cogTurningAnimation.Position = cogPosition;
            ani.IsLooping = true;
            cogTurningAnimation.AddAnimation("TurningRight", 1, 3, ani.Copy());
            //cogTurningAnimation.AddAnimation("TurningLeft", 2, 6, ani.Copy());

            cogTurningAnimation.Animation = "TurningRight";


        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (cogTurningAnimation.Animation != null)
            {
                cogTurningAnimation.Draw(spriteBatch,1f);
            }


        }
        public void Update(GameTime gameTime)
        {
            cogTurningAnimation.Update(gameTime);
        }
    }
}
