﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    public class CheckMark
    {
        private Texture2D checkMarkTexture;
        private Vector2 checkMarkPosition;        
        private int checkMarkWidth;
        private int checkMarkHeight;
        private float fCheckMarkZoom;
        private string layerType;


        public int CheckMarkWidth
        {
            get { return checkMarkWidth; }
            set { checkMarkWidth = value; }
        }
        public int CheckMarkHeight
        {
            get { return checkMarkHeight; }
            set { checkMarkHeight = value; }
        }
        public string LayerType
        {
            get { return layerType; }
            set { layerType = value; }
        }
        //Constructor
        public CheckMark(Vector2 checkMarkPosition,string layerType)
        {
            this.checkMarkPosition = checkMarkPosition;
            this.layerType = layerType;
            fCheckMarkZoom = 1.0f;

        }
        public void LoadContent(ContentManager Content)
        {

            checkMarkTexture = Content.Load<Texture2D>("CustomerOrderBoard/CheckMark16x16");
            checkMarkWidth = (int)(checkMarkTexture.Width * fCheckMarkZoom);
            checkMarkHeight = (int)(checkMarkTexture.Height * fCheckMarkZoom); ;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(checkMarkTexture,checkMarkPosition, null, Color.White, 0f,
            Vector2.Zero, fCheckMarkZoom, SpriteEffects.None, 0f);
        }

    }
}
