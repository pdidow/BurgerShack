﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace BurgerShack
{
    //The FlameBroiler poops out Burger Pattys
    public class FlameBroiler
    {
        private SpriteAnimation flameSpriteAnimation;//Contains our animation sequences
        private Vector2 flamePosition;
        private BurgerPatty patty;
        private List<BurgerPatty> pattyList;
        public List<BurgerPatty> PattyList
            {
            get { return pattyList; }
            set { PattyList = value; }
            }
        public FlameBroiler()
        {
            flamePosition = new Vector2(330, 100);
            pattyList = new List<BurgerPatty>();
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (flameSpriteAnimation.Animation != null)
            {
                flameSpriteAnimation.Draw(spriteBatch,1f);
            }
        }
        public void Update(GameTime gameTime)
        {
            flameSpriteAnimation.Update(gameTime);
           

        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            flameSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Flames/flames"),12,1); //#frames, # animtions
            flameSpriteAnimation.FramesPerSecond = 15;

            ani.IsLooping = true;
            flameSpriteAnimation.AddAnimation("Burn",1,12, ani.Copy());
           
            flameSpriteAnimation.Animation = "Burn";
            flameSpriteAnimation.Position = flamePosition;
    
        }
        public void AddBurgerPatty(ContentManager Content)
        {
            //On timer, generate new patty.
            patty = new BurgerPatty(new Vector2((int)flamePosition.X - 12, (int)flamePosition.Y +8));
            
            patty.LoadContent(Content);
            pattyList.Add(patty);
        }
    }
}
